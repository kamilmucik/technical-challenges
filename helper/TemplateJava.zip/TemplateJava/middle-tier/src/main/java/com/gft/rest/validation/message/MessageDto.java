package com.gft.rest.validation.message;

/**
 * Created by azws on 2016-08-14.
 */
public class MessageDto {

    private String message;
    private MessageType type;

    public MessageDto(String message, MessageType type) {
        this.message = message;
        this.type = type;
    }

    public MessageDto(MessageType type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public MessageType getType() {
        return type;
    }

    public void setType(MessageType type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "MessageDto{" +
                "message='" + message + '\'' +
                ", type=" + type +
                '}';
    }
}
