package com.gft.rest.controllers;

import com.gft.dao.service.MiddleTierRepositoryService;
import com.gft.dto.OrderDto;
import com.gft.dto.OrderStatus;
import com.gft.dto.ProductDto;
import com.gft.jms.sender.OrderService;
import com.gft.message.AvailableProductsResponse;
import com.gft.message.NewOrderResponse;
import com.gft.model.Product;
import com.gft.rest.domain.CurrentUser;
import com.gft.rest.validation.ErrorCode;
import com.gft.rest.validation.MyValidator;
import com.gft.rest.validation.message.MessageDto;
import com.gft.rest.validation.message.MessageFormatter;
import com.gft.rest.validation.message.MessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-07-18.
 */
@Controller
public class OrderController {

    private final static Logger LOGGER = LoggerFactory.getLogger(OrderController.class);

    private OrderService orderService;
    private CurrentUser currentUser; //temporary field
    private MessageFormatter messageFormatter;
    private MiddleTierRepositoryService middleTierRepositoryService;

    @Autowired
    public OrderController(OrderService orderService, CurrentUser currentUser, MessageFormatter messageFormatter, MiddleTierRepositoryService middleTierRepositoryService) {
        this.orderService = orderService;
        this.currentUser = currentUser;
        this.messageFormatter = messageFormatter;
        this.middleTierRepositoryService = middleTierRepositoryService;
    }

    @RequestMapping(value = "/trade/getAvailableProducts", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public DeferredResult<Page<ProductDto>> getAvailableProducts(Pageable pageable) {
        DeferredResult<Page<ProductDto>> deferredResult = new DeferredResult<>();
        CompletableFuture<AvailableProductsResponse> completableFuture = orderService.sendGetAvailableProductsRequest(pageable);
        completableFuture.whenComplete((res, ex) -> {
            if (ex != null) {
                LOGGER.error("Completable future error", ex);
                deferredResult.setErrorResult(ex);
            } else {
                deferredResult.setResult(res.getAvailableProducts());
            }
        });
        return deferredResult;
    }

    @RequestMapping(value = "/trade/saveOrder", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @CrossOrigin
    public DeferredResult<ResponseEntity<MessageDto>> saveOrder(@RequestBody OrderDto orderDto, BindingResult bindingResult) {
        DeferredResult<ResponseEntity<MessageDto>> deferredResult = new DeferredResult<>();
        MyValidator.validateOrder(orderDto, bindingResult);
        if (!bindingResult.hasErrors()) {
            Product product = middleTierRepositoryService.getProduct(orderDto.getProductId());
            if (product != null) {
                CompletableFuture<NewOrderResponse> completableFuture = orderService.sendCreateNewOrderRequest(currentUser.getId(), orderDto);
                completableFuture.whenComplete((res, ex) -> {
                    if (ex != null) {
                        LOGGER.error("Completable future error", ex);
                        deferredResult.setErrorResult(ex);
                    } else {
                        OrderStatus orderStatus = res.getOrderStatus();
                        deferredResult.setResult(ResponseEntity.ok().body(new MessageDto(orderStatus.toString(), orderStatus.equals(OrderStatus.OK) ? MessageType.SUCCESS : MessageType.WARNING)));
                    }
                });
            } else {
                deferredResult.setErrorResult(ResponseEntity.ok().body(messageFormatter.processError(ErrorCode.PRODUCT_ID_INCORRECT.toString())));
            }
        } else {
            LOGGER.error("Validation error", bindingResult.getFieldError());
            deferredResult.setErrorResult(ResponseEntity.badRequest().body(messageFormatter.processFieldError(bindingResult.getFieldError())));
        }
        return deferredResult;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseBody
    public MessageDto handleErrorParsingJsonToObject() {
        return messageFormatter.processError(ErrorCode.BAD_PARSING_DATA.toString());
    }

}
