package com.gft.rest.validation;

import com.gft.dto.OrderDto;
import com.gft.dto.OrderType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import java.math.BigDecimal;

/**
 * Created by azws on 2016-08-12.
 */
public class OrderValidator extends MyValidator {

    private final static Logger LOGGER = LoggerFactory.getLogger(OrderValidator.class);

    @Override
    public boolean supports(Class<?> aClass) {
        return OrderDto.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        OrderDto orderDto = (OrderDto) o;

        LOGGER.debug("Validating {} class object", orderDto.getClass().getName());

        ValidationUtils.rejectIfEmpty(errors, "productId", ErrorCode.PRODUCT_ID_EMPTY.toString());
        ValidationUtils.rejectIfEmpty(errors, "volume", ErrorCode.VOLUME_EMPTY.toString());
        ValidationUtils.rejectIfEmpty(errors, "orderType", ErrorCode.ORDER_TYPE_EMPTY.toString());
        ValidationUtils.rejectIfEmpty(errors, "price", ErrorCode.PRICE_EMPTY.toString());

        if (!errors.hasFieldErrors("productId")) {
            if (orderDto.getProductId() != null && orderDto.getProductId() <= 0)
                errors.rejectValue("productId", ErrorCode.PRODUCT_ID_NONPOSITIVE.toString());
        }
        if (!errors.hasFieldErrors("volume")) {
            if (orderDto.getVolume() != null && orderDto.getVolume() <= 0)
                errors.rejectValue("volume", ErrorCode.VOLUME_NONPOSITIVE.toString());
        }
        if (!errors.hasFieldErrors("price")) {
            if (orderDto.getPrice() != null && (orderDto.getPrice().compareTo(BigDecimal.ZERO) == -1 || orderDto.getPrice().compareTo(BigDecimal.ZERO) == 0))
                errors.rejectValue("price", ErrorCode.PRICE_NONPOSITIVE.toString());
        }
        if (!errors.hasFieldErrors("orderType")) {
            if (orderDto.getOrderType() != null && (!orderDto.getOrderType().equals(OrderType.SALE) && !orderDto.getOrderType().equals(OrderType.PURCHASE)))
                errors.rejectValue("orderType", ErrorCode.BAD_PARSING_DATA.toString());
        }
    }
}
