package com.gft.jms.sender.impl;

import com.gft.JmsType;
import com.gft.dto.UserDto;
import com.gft.jms.sender.SenderService;
import com.gft.jms.sender.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-08-17.
 */

@Service
public class UserServiceImpl implements UserService {

    private final static Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    private SenderService senderService;

    @Autowired
    public UserServiceImpl(SenderService senderService) {
        this.senderService = senderService;
    }

    @Override
    public CompletableFuture<UserDto> sendGetUserRequest(Long userId) {
        LOGGER.debug("Creating message 'get user's data request' for user with id: {}", userId);
        CompletableFuture<UserDto> completableFuture = senderService.prepareAndSend(userId, JmsType.GET_USER);
        return completableFuture;
    }
}
