package com.gft.dao.service;

import com.gft.model.Product;
import com.gft.model.User;

/**
 * Created by azws on 2016-07-18.
 */

public interface MiddleTierRepositoryService {

    User getUser(String login);

    Product getProduct(Long productId);


}
