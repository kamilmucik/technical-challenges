package com.gft.rest.controllers;

import com.gft.dto.AssetDto;
import com.gft.dto.OrderDto;
import com.gft.dto.QuotationDto;
import com.gft.jms.sender.DashboardService;
import com.gft.message.ActiveOrdersResponse;
import com.gft.message.OwnedAssetsResponse;
import com.gft.message.StockQuotesResponse;
import com.gft.rest.domain.CurrentUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-07-18.
 */

@Controller
public class DashboardController {

    private final static Logger LOGGER = LoggerFactory.getLogger(DashboardController.class);

    private DashboardService dashboardService;
    private CurrentUser currentUser; //temporary field

    @Autowired
    public DashboardController(DashboardService dashboardService, CurrentUser currentUser) {
        this.dashboardService = dashboardService;
        this.currentUser = currentUser;
    }

    @RequestMapping(value = "/getActiveOrders", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public DeferredResult<Page<OrderDto>> getActiveOrders(Pageable pageable) {
        DeferredResult<Page<OrderDto>> deferredResult = new DeferredResult<>();
        CompletableFuture<ActiveOrdersResponse> completableFuture = dashboardService.sendGetActiveOrdersRequest(currentUser.getId(), pageable);
        completableFuture.whenComplete((res, ex) -> {
            if (ex != null) {
                LOGGER.error("Completable future error", ex);
                deferredResult.setErrorResult(ex);
            } else {
                deferredResult.setResult(res.getActiveOrders());
            }
        });
        return deferredResult;
    }

    @RequestMapping(value = "/getOwnedAssets", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public DeferredResult<Page<AssetDto>> getMyAssets(Pageable pageable) {
        DeferredResult<Page<AssetDto>> deferredResult = new DeferredResult<>();
        CompletableFuture<OwnedAssetsResponse> completableFuture = dashboardService.sendGetOwnedAssetsRequest(currentUser.getId(), pageable);
        completableFuture.whenComplete((res, ex) -> {
            if (ex != null) {
                LOGGER.error("Completable future error", ex);
                deferredResult.setErrorResult(ex);
            } else {
                deferredResult.setResult(res.getOwnedAssets());
            }
        });
        return deferredResult;
    }

    @RequestMapping(value = "/getStockQuotes", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public DeferredResult<Page<QuotationDto>> getStockQuotes(Pageable pageable) {
        DeferredResult<Page<QuotationDto>> deferredResult = new DeferredResult<>();
        CompletableFuture<StockQuotesResponse> completableFuture = dashboardService.sendGetStockQuotesRequest(pageable);
        completableFuture.whenComplete((res, ex) -> {
            if (ex != null) {
                LOGGER.error("Completable future error", ex);
                deferredResult.setErrorResult(ex);
            } else {
                deferredResult.setResult(res.getStockQuotes());
            }
        });
        return deferredResult;
    }

}