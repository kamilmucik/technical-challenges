package com.gft.model;

import javax.persistence.*;

/**
 * Created by azws on 2016-08-03.
 */

@Entity
@Table(name = "\"product\"")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id", unique = true, nullable = false)
    private Long productId;

    @Column(name = "backend_instance_id", nullable = false)
    private Long backendInstanceId;

    public Product() {
    }

    public Product(Long productId, Long backendInstanceId) {
        this.productId = productId;
        this.backendInstanceId = backendInstanceId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getBackendInstanceId() {
        return backendInstanceId;
    }

    public void setBackendInstanceId(Long backendInstanceId) {
        this.backendInstanceId = backendInstanceId;
    }
}
