package com.gft.socket.sender.impl;

import com.gft.socket.sender.SocketSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.core.MessageSendingOperations;
import org.springframework.stereotype.Service;

/**
 * Created by azws on 2016-08-30.
 */

@Service
public class SocketSenderServiceImpl implements SocketSenderService {

    private MessageSendingOperations<String> messagingTemplate;

    @Autowired
    public SocketSenderServiceImpl(MessageSendingOperations<String> messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @Override
    public void sendMessage(String destination, Object message) {
        messagingTemplate.convertAndSend(destination, message);
    }
}
