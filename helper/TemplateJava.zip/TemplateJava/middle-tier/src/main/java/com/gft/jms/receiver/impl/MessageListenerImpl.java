package com.gft.jms.receiver.impl;

import com.gft.jms.receiver.ReceiverService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

/**
 * Created by azws on 2016-07-21.
 */
public class MessageListenerImpl implements MessageListener {

    private final static Logger LOGGER = LoggerFactory.getLogger(MessageListenerImpl.class);

    @Autowired
    private ReceiverService receiverService;

    private ObjectMessage receiveMessage(Message message) {
        LOGGER.debug("Casting message received in middle tier to ObjectMessage object");
        ObjectMessage objectMessage = null;
        if(message instanceof ObjectMessage) {
            objectMessage = (ObjectMessage) message;
        }
        return objectMessage;
    }

    @Override
    public void onMessage(Message message) {
        ObjectMessage receivedMessage = receiveMessage(message);
        try {
            receiverService.handleRespond(receivedMessage);
        } catch (JMSException e) {
            LOGGER.error("Error receiving message in middle tier", e);
        }
    }
}
