package com.gft.jms.sender;

import com.gft.JmsType;
import com.gft.dto.OrderStatus;
import com.gft.message.ActiveOrdersResponse;
import com.gft.dto.OrderDto;
import com.gft.dto.ProductDto;
import com.gft.dto.UserDto;
import com.gft.message.AvailableProductsResponse;
import com.gft.message.NewOrderResponse;
import com.gft.message.OwnedAssetsResponse;
import org.springframework.data.domain.Pageable;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-07-13.
 */
public interface SenderService {

    <T, M extends Serializable> CompletableFuture<T> prepareAndSend(M message, JmsType jmsType);

}
