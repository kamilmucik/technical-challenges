package com.gft.rest.validation.message;

/**
 * Created by azws on 2016-08-14.
 */
public enum MessageType {

    SUCCESS, INFO, WARNING, ERROR
}
