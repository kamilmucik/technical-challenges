package com.gft.rest.domain;

import com.gft.model.Role;
import com.gft.model.Status;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.persistence.*;

/**
 * Created by azws on 2016-07-13.
 */

public class CurrentUser {

    private Long id;
    private String login;
    private String email;
    private Role role;
    private Status status;

    public CurrentUser() {
    }

    public CurrentUser(Long id, String login, String email, Role role, Status status) {
        this.id = id;
        this.login = login;
        this.email = email;
        this.role = role;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public CurrentUser setId(Long id) {
        this.id = id;
        return this;
    }

    public String getLogin() {
        return login;
    }

    public CurrentUser setLogin(String login) {
        this.login = login;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public CurrentUser setEmail(String email) {
        this.email = email;
        return this;
    }

    public Role getRole() {
        return role;
    }

    public CurrentUser setRole(Role role) {
        this.role = role;
        return this;
    }

    public Status getStatus() {
        return status;
    }

    public CurrentUser setStatus(Status status) {
        this.status = status;
        return this;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", login='" + login + '\'' +
                ", email='" + email + '\'' +
                ", role=" + role +
                ", status=" + status +
                '}';
    }
}
