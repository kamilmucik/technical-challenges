package com.gft.dao;

import com.gft.model.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * Created by azws on 2016-07-28.
 */

@Repository
public interface UserDao extends CrudRepository<User, Long> {

    User findUserByLogin(String login);

}
