package com.gft.jms.sender;

import com.gft.dto.OrderDto;
import com.gft.message.AvailableProductsResponse;
import com.gft.message.NewOrderResponse;
import org.springframework.data.domain.Pageable;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-08-17.
 */
public interface OrderService {

    CompletableFuture<NewOrderResponse> sendCreateNewOrderRequest(Long userId, OrderDto orderDto);

    CompletableFuture<AvailableProductsResponse> sendGetAvailableProductsRequest(Pageable pageable);
}
