package com.gft.rest.validation;

/**
 * Created by azws on 2016-08-12.
 */
public enum ErrorCode {

    LOGIN_EMPTY ("error.login.empty"),
    PASSWORD_EMPTY ("error.password.empty"),
    PRODUCT_ID_EMPTY ("error.productId.empty"),
    VOLUME_EMPTY ("error.volume.empty"),
    ORDER_TYPE_EMPTY ("error.orderType.empty"),
    PRICE_EMPTY ("error.price.empty"),

    PRODUCT_ID_NONPOSITIVE ("error.productId.nonpositive"),
    VOLUME_NONPOSITIVE ("error.volume.nonpositive"),
    PRICE_NONPOSITIVE ("error.price.nonpositive"),

    PRODUCT_ID_INCORRECT ("error.productId.incorrect"),

    BAD_PARSING_DATA ("error.bad.parsing"),

    LOGIN_SIZE ("error.login.size"),
    LOGIN_WHITESPACE ("error.login.whitespace"),

    PASSWORD_SIZE ("error.password.size");

    private final String errorMessage;

    private ErrorCode(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String toString() {
        return this.errorMessage;
    }
}
