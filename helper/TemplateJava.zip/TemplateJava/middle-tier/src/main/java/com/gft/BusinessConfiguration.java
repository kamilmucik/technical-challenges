package com.gft;

import com.gft.rest.domain.CurrentUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.socket.server.standard.ServletServerContainerFactoryBean;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by azws on 2016-07-31.
 */
@Configuration
public class BusinessConfiguration {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessConfiguration.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("classpath:add_new_user.txt")
    private Resource newUserScriptResource;

    @Value("classpath:add_backend_products.txt")
    private Resource backendProductsScriptResource;

    @PostConstruct
    public void runSqlScripts() throws Exception {
        executeDBScripts(newUserScriptResource.getInputStream());
        executeDBScripts(backendProductsScriptResource.getInputStream());
    }

    private void executeDBScripts(InputStream inputStream) throws IOException, SQLException {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            String str;
            StringBuffer sb = new StringBuffer();
            while ((str = in.readLine()) != null) {
                sb.append(str + "\n ");
            }
            in.close();
            jdbcTemplate.execute(sb.toString());
        } catch (Exception e) {
            LOGGER.error("Error executing sql script", e);
        }
    }

    @Bean
    public CurrentUser currentUser() {
        return new CurrentUser();
    }

    @Bean
    public ConcurrentHashMap<String, CompletableFuture> matchingMessagesMap() {
        return new ConcurrentHashMap<>();
    }

    @Bean
    public ServletServerContainerFactoryBean createWebSocketContainer() {
        ServletServerContainerFactoryBean container = new ServletServerContainerFactoryBean();
        container.setMaxTextMessageBufferSize(8192);
        container.setMaxBinaryMessageBufferSize(8192);
        return container;
    }

}
