package com.gft.rest.validation;

import com.gft.dto.OrderDto;
import com.gft.rest.domain.AuthCredentials;
import javafx.util.Pair;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Created by azws on 2016-08-16.
 */
public abstract class MyValidator implements Validator {

    public static void validateAuth(AuthCredentials authCredentials, Errors errors) {
        new LogInValidator().validate(authCredentials, errors);
    }

    public static void validateOrder(OrderDto orderDto, Errors errors) {
        new OrderValidator().validate(orderDto, errors);
    }

}
