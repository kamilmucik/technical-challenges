package com.gft.jms.receiver.impl;

import com.gft.jms.receiver.ReceiverService;
import com.gft.jms.sender.impl.SenderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by azws on 2016-07-21.
 */

@Service
public class ReciverServiceImpl implements ReceiverService {

    @Autowired
    public ConcurrentHashMap<String, CompletableFuture> matchingMessagesMap;

    @Override
    public void handleRespond(ObjectMessage objectMessage) throws JMSException {
        String correlationId = objectMessage.getJMSCorrelationID();
        if(matchingMessagesMap.keySet().contains(correlationId)) {
            matchingMessagesMap.get(correlationId).complete(objectMessage.getObject());
            matchingMessagesMap.remove(correlationId);
        }
    }

}
