package com.gft.dao;

import com.gft.model.Product;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by azws on 2016-07-28.
 */
public interface ProductDao extends CrudRepository<Product, Long> {

    Product findByProductId(Long productId);
}
