package com.gft.jms.sender.impl;

import com.gft.JmsType;
import com.gft.jms.sender.SenderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.Session;
import java.io.Serializable;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by azws on 2016-07-13.
 */

@Service
public class SenderServiceImpl implements SenderService {

    private final static Logger LOGGER = LoggerFactory.getLogger(SenderServiceImpl.class);

    @Autowired
    public ConcurrentHashMap<String, CompletableFuture> matchingMessagesMap;

    @Autowired
    private String middleToBackQueue;

    private final JmsTemplate jmsTemplate;

    @Autowired
    public SenderServiceImpl(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    private <T extends Serializable> MessageCreator createObjectMessage(T message, JmsType jmsType, String correlationId) {
        LOGGER.debug("Creating object message with correlation ID: ", correlationId);
        return (Session session) -> {
            Message messageToSend = session.createObjectMessage(message);
            messageToSend.setJMSType(jmsType.toString());
            messageToSend.setJMSCorrelationID(correlationId);
            return messageToSend;
        };
    }

    public <T, M extends Serializable> CompletableFuture<T> prepareAndSend(M message, JmsType jmsType) {
        LOGGER.debug("Preparing message for sending to backend with JMS type: {}", jmsType);
        CompletableFuture<T> completableFuture = new CompletableFuture<>();
        String correlationId = UUID.randomUUID().toString();
        MessageCreator completeMessage = createObjectMessage(message, jmsType, correlationId);
        matchingMessagesMap.put(correlationId, completableFuture);
        jmsTemplate.send(middleToBackQueue, completeMessage);
        LOGGER.debug("Sending message to backend with JMS type: {} and correlation ID: {}", jmsType, correlationId);
        return completableFuture;
    }

}
