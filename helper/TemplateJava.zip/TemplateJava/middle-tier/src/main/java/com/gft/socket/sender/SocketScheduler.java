package com.gft.socket.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Created by azws on 2016-08-30.
 */

@Component
public class SocketScheduler {

    private DashboardSocketService dashboardSocketService;

    @Autowired
    public SocketScheduler(DashboardSocketService dashboardSocketService) {
        this.dashboardSocketService = dashboardSocketService;
    }

    @Scheduled(fixedRate = 5000)
    private void sendPeriodMessage() {
        dashboardSocketService.sendStockQuotes();
    }

}
