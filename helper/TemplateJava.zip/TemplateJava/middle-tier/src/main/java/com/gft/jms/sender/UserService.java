package com.gft.jms.sender;

import com.gft.dto.UserDto;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-08-17.
 */
public interface UserService {

    CompletableFuture<UserDto> sendGetUserRequest(Long userId);

}
