package com.gft.jms.sender.impl;

import com.gft.JmsType;
import com.gft.dto.OrderDto;
import com.gft.jms.sender.OrderService;
import com.gft.jms.sender.SenderService;
import com.gft.message.AvailableProductsRequest;
import com.gft.message.AvailableProductsResponse;
import com.gft.message.NewOrderRequest;
import com.gft.message.NewOrderResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-08-18.
 */

@Service
public class OrderServiceImpl implements OrderService {

    private final static Logger LOGGER = LoggerFactory.getLogger(OrderServiceImpl.class);

    private SenderService senderService;

    @Autowired
    public OrderServiceImpl(SenderService senderService) {
        this.senderService = senderService;
    }

    @Override
    public CompletableFuture<NewOrderResponse> sendCreateNewOrderRequest(Long userId, OrderDto orderDto) {
        LOGGER.debug("Creating message 'create new order request' for user with id: {}", userId);
        NewOrderRequest newOrderRequest = new NewOrderRequest(userId, orderDto);
        CompletableFuture<NewOrderResponse> completableFuture = senderService.prepareAndSend(newOrderRequest, JmsType.CREATE_NEW_ORDER);
        return completableFuture;
    }

    @Override
    public CompletableFuture<AvailableProductsResponse> sendGetAvailableProductsRequest(Pageable pageable) {
        LOGGER.debug("Creating message 'get available products request'");
        AvailableProductsRequest availableProductsRequest = new AvailableProductsRequest(pageable);
        CompletableFuture<AvailableProductsResponse> completableFuture = senderService.prepareAndSend(availableProductsRequest, JmsType.GET_PRODUCTS_LIST);
        return completableFuture;
    }
}
