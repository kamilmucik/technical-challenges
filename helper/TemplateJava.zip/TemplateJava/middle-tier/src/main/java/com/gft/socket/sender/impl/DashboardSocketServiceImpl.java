package com.gft.socket.sender.impl;

import com.gft.jms.sender.DashboardService;
import com.gft.rest.controllers.AuthenticationController;
import com.gft.socket.sender.DashboardSocketService;
import com.gft.socket.sender.SocketSenderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutionException;

/**
 * Created by azws on 2016-08-30.
 */

@Service
public class DashboardSocketServiceImpl implements DashboardSocketService {

    private final static Logger LOGGER = LoggerFactory.getLogger(DashboardSocketServiceImpl.class);

    private SocketSenderService socketSenderService;
    private DashboardService dashboardService;

    @Autowired
    private String stockQuotesDestination;

    @Autowired
    public DashboardSocketServiceImpl(SocketSenderService socketSenderService, DashboardService dashboardService) {
        this.socketSenderService = socketSenderService;
        this.dashboardService = dashboardService;
    }

    @Override
    public void sendStockQuotes() {
        try {
            socketSenderService.sendMessage(stockQuotesDestination, dashboardService.sendGetStockQuotesRequest(new PageRequest(0, Integer.MAX_VALUE)).get());
        } catch (InterruptedException e) {
            LOGGER.error("ERROR", e);
            e.printStackTrace();
        } catch (ExecutionException e) {
            LOGGER.error("ERROR", e);
        }
    }
}
