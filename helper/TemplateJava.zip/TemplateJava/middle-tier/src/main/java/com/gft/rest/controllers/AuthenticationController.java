package com.gft.rest.controllers;

import com.gft.dao.service.MiddleTierRepositoryService;
import com.gft.dto.UserDto;
import com.gft.jms.sender.UserService;
import com.gft.model.User;
import com.gft.rest.domain.AuthCredentials;
import com.gft.rest.domain.CurrentUser;
import com.gft.rest.validation.MyValidator;
import com.gft.rest.validation.message.MessageDto;
import com.gft.rest.validation.message.MessageFormatter;
import com.gft.rest.validation.message.MessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-07-18.
 */
@Controller
public class AuthenticationController {

    private final static Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

    private MiddleTierRepositoryService middleTierRepositoryService;
    private UserService userService;
    private CurrentUser currentUser; //temporary field
    private MessageFormatter messageFormatter;

    @Autowired
    public AuthenticationController(MiddleTierRepositoryService middleTierRepositoryService, UserService userService, CurrentUser currentUser, MessageFormatter messageFormatter) {
        this.middleTierRepositoryService = middleTierRepositoryService;
        this.userService = userService;
        this.currentUser = currentUser;
        this.messageFormatter = messageFormatter;
    }

    @RequestMapping(value = "/login/submit", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @CrossOrigin
    public ResponseEntity<MessageDto> logIn(@RequestBody AuthCredentials authCredentials, BindingResult bindingResult) {
        MessageDto messageDto;
        HttpStatus httpStatus;
        MyValidator.validateAuth(authCredentials, bindingResult);
        if (!bindingResult.hasErrors()) {
            User user = middleTierRepositoryService.getUser(authCredentials.getLogin());
            httpStatus = HttpStatus.UNAUTHORIZED;
            if (user != null) {
                if (user.getPassword().equals(authCredentials.getPassword())) {
                    LOGGER.debug("Authentication user with id: {}", user.getId());
                    httpStatus = HttpStatus.OK;
                    currentUser.setId(user.getId()).setEmail(user.getEmail()).setLogin(user.getLogin()).setRole(user.getRole()).setStatus(user.getStatus());
                }
            }
            String credentialValidationMessage = "OK";
            if (httpStatus.equals(HttpStatus.UNAUTHORIZED) && user != null) {

                LOGGER.info("Inserted password for user with id: {} is invalid", user.getId());
                credentialValidationMessage = "INVALID_PASSWORD";
            } else if (user == null) {

                LOGGER.info("There is no registered user with login: {}", authCredentials.getLogin());
                credentialValidationMessage = "INVALID_LOGIN";
            }
            messageDto = new MessageDto(credentialValidationMessage, MessageType.SUCCESS);
        } else {
            messageDto = messageFormatter.processFieldError(bindingResult.getFieldError());
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        return ResponseEntity.status(httpStatus).body(messageDto);
    }

    @RequestMapping(value = "/getUser", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public DeferredResult<UserDto> getUser() {
        DeferredResult<UserDto> deferredResult = new DeferredResult<>();
        CompletableFuture<UserDto> completableFuture = userService.sendGetUserRequest(currentUser.getId());
        completableFuture.whenComplete((res, ex) -> {
            if (ex != null) {
                LOGGER.error("Completable future error", ex);
                deferredResult.setErrorResult(ex);
            } else {
                res.setLogin(currentUser.getLogin());
                deferredResult.setResult(res);
            }
        });
        return deferredResult;
    }

}