package com.gft.jms.sender.impl;

import com.gft.JmsType;
import com.gft.jms.sender.DashboardService;
import com.gft.jms.sender.SenderService;
import com.gft.message.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-08-18.
 */
@Service
public class DashboardServiceImpl implements DashboardService {

    private final static Logger LOGGER = LoggerFactory.getLogger(DashboardServiceImpl.class);

    private SenderService senderService;

    @Autowired
    public DashboardServiceImpl(SenderService senderService) {
        this.senderService = senderService;
    }

    @Override
    public CompletableFuture<OwnedAssetsResponse> sendGetOwnedAssetsRequest(Long userId, Pageable pageable) {
        LOGGER.debug("Creating message 'get owned assets request' by user with id: {} request", userId);
        OwnedAssetsRequest ownedAssetsRequest = new OwnedAssetsRequest(userId, pageable);
        CompletableFuture<OwnedAssetsResponse> completableFuture = senderService.prepareAndSend(ownedAssetsRequest, JmsType.GET_OWNED_ASSETS);
        return completableFuture;
    }

    @Override
    public CompletableFuture<ActiveOrdersResponse> sendGetActiveOrdersRequest(Long userId, Pageable pageable) {
        LOGGER.debug("Creating message 'get active orders request' by user with id: {} request", userId);
        ActiveOrdersRequest activeOrdersRequest = new ActiveOrdersRequest(userId, pageable);
        CompletableFuture<ActiveOrdersResponse> completableFuture = senderService.prepareAndSend(activeOrdersRequest, JmsType.GET_ACTIVE_ORDERS);
        return completableFuture;
    }

    @Override
    public CompletableFuture<StockQuotesResponse> sendGetStockQuotesRequest(Pageable pageable) {
        LOGGER.debug("Creating message 'get stock quotes request");
        StockQuotesRequest stockQuotesRequest = new StockQuotesRequest(pageable);
        CompletableFuture<StockQuotesResponse> completableFuture = senderService.prepareAndSend(stockQuotesRequest, JmsType.GET_STOCK_QUOTES);
        return completableFuture;
    }
}
