package com.gft.rest.validation.message;

import com.gft.rest.controllers.AuthenticationController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;

import java.util.Locale;

/**
 * Created by azws on 2016-08-16.
 */
@Component
public class MessageFormatter {

    private final static Logger LOGGER = LoggerFactory.getLogger(MessageFormatter.class);

    @Autowired
    private MessageSource msgSource;

    public MessageDto processFieldError(FieldError error) {
        MessageDto message = null;
        if (error != null) {
            Locale currentLocale = LocaleContextHolder.getLocale();
            String msg = msgSource.getMessage(error.getCode(), null, currentLocale);
            LOGGER.error("Validation error", msg);
            message = new MessageDto(msg, MessageType.ERROR);
        }
        return message;
    }

    public MessageDto processError(String errorCode) {
        Locale currentLocale = LocaleContextHolder.getLocale();
        String msg = msgSource.getMessage(errorCode, null, currentLocale);
        LOGGER.error("Validation error", msg);

        return new MessageDto(msg, MessageType.ERROR);
    }
}
