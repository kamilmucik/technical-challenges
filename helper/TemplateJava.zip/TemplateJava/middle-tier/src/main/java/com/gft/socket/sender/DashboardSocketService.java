package com.gft.socket.sender;

/**
 * Created by azws on 2016-08-30.
 */
public interface DashboardSocketService {

    void sendStockQuotes();
}
