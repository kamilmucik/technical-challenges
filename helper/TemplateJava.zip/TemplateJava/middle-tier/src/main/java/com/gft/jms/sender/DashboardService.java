package com.gft.jms.sender;

import com.gft.message.ActiveOrdersResponse;
import com.gft.message.OwnedAssetsResponse;
import com.gft.message.StockQuotesResponse;
import org.springframework.data.domain.Pageable;

import java.util.concurrent.CompletableFuture;

/**
 * Created by azws on 2016-08-18.
 */
public interface DashboardService {

    CompletableFuture<OwnedAssetsResponse> sendGetOwnedAssetsRequest(Long userId, Pageable pageable);

    CompletableFuture<ActiveOrdersResponse> sendGetActiveOrdersRequest(Long userId, Pageable pageable);

    CompletableFuture<StockQuotesResponse> sendGetStockQuotesRequest(Pageable pageable);


}
