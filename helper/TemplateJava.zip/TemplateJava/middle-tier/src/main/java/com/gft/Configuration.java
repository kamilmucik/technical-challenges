package com.gft;

import com.gft.socket.WebSocketConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by e-klbi on 2016-06-28.
 */
@SpringBootApplication(scanBasePackages = "com.gft")
@ImportResource("/beans.xml")
@Import(value = {BusinessConfiguration.class, WebSocketConfig.class})
public class Configuration  {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Configuration.class, args);
    }


}
