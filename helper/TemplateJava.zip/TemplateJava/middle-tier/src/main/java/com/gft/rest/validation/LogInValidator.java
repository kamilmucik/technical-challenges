package com.gft.rest.validation;

import com.gft.rest.domain.AuthCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

/**
 * Created by azws on 2016-08-12.
 */
@Service
public class LogInValidator extends MyValidator {

    private final static Logger LOGGER = LoggerFactory.getLogger(LogInValidator.class);

    @Override
    public boolean supports(Class<?> aClass) {
        return AuthCredentials.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        AuthCredentials authCredentials = (AuthCredentials) o;

        LOGGER.debug("Validating {} class object", authCredentials.getClass().getName());

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "login", ErrorCode.LOGIN_EMPTY.toString());
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", ErrorCode.PASSWORD_EMPTY.toString());

        if (!errors.hasFieldErrors("login")) {
            if (authCredentials.getLogin() != null) {
                if (StringUtils.containsWhitespace(authCredentials.getLogin())) {
                    errors.rejectValue("login", ErrorCode.LOGIN_WHITESPACE.toString());
                }
                if (authCredentials.getLogin().length() > 20 || authCredentials.getLogin().length() < 4) {
                    errors.rejectValue("login", ErrorCode.LOGIN_SIZE.toString());
                }
            }
        }

        if (!errors.hasFieldErrors("password")) {
            if (authCredentials.getPassword() != null && (authCredentials.getPassword().length() > 20 || authCredentials.getPassword().length() < 4))
                errors.rejectValue("password", ErrorCode.PASSWORD_SIZE.toString());
        }

    }
}
