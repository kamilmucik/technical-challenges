package com.gft.model;

/**
 * Created by azws on 2016-08-06.
 */
public enum Role {

    USER, ADMIN

}
