package com.gft.jms.receiver;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;

/**
 * Created by azws on 2016-07-21.
 */
public interface ReceiverService {

    void handleRespond(ObjectMessage objectMessage) throws JMSException;
}
