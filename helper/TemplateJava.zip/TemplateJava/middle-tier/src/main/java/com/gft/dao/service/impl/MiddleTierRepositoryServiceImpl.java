package com.gft.dao.service.impl;

import com.gft.dao.ProductDao;
import com.gft.dao.UserDao;
import com.gft.dao.service.MiddleTierRepositoryService;
import com.gft.model.Product;
import com.gft.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by azws on 2016-07-18.
 */

@Service
public class MiddleTierRepositoryServiceImpl implements MiddleTierRepositoryService {


    private final static Logger LOGGER = LoggerFactory.getLogger(MiddleTierRepositoryServiceImpl.class);

    private UserDao userDao;

    private ProductDao productDao;

    @Autowired
    public MiddleTierRepositoryServiceImpl(UserDao userDao, ProductDao productDao) {
        this.userDao = userDao;
        this.productDao = productDao;
    }

    @Override
    public User getUser(String login) {
        LOGGER.debug("Getting user with login: {} from database", login);
        return userDao.findUserByLogin(login);
    }

    @Override
    public Product getProduct(Long productId) {
        LOGGER.debug("Getting product with id: {} from database", productId);
        return productDao.findByProductId(productId);
    }
}
