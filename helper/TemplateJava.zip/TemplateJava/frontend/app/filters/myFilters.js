(function () {
  'use strict';
    var app = angular.module('juniorProject');

    app.filter('buy_sell', function () {
      return function (input) {
        if (input === 'PURCHASE') {
          return 'buy';
        } else {
          return 'sell';
        }
      };
    });



})();