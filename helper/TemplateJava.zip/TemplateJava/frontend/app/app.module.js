(function () {
  'use strict';

  // Define the `juniorProject` module
  var app = angular.module('juniorProject', [
    'ngAnimate',
    'ngMaterial',
    'ngMessages',
    'ui.router',
    'App.Pages.Dashboard',
    'App.Pages.Login',
    'App.Pages.Trade',
    'App.Pages.History'

  ]);

  app.constant('appConfig', {
    'baseURL': 'http://10.200.202.108:8082/', // 10.48.3.128:8070 Kasia's computer ; 10.200.202.108:8082 TeamCity
    'endPoints': {
      'getActiveOrders': 'getActiveOrders',               // dashboard get - dane, które się aktualizują po dokonaniu transakcji
      'getQuotations' : 'quotations',                     // dashboard get - 
      'getResources' : 'wallet',                          // dashboard get - dane do rysowania wykresu
      'getMyAssets' : 'getOwnedAssets',                   // dashboard get - 
      'getUser' : 'getUser',                              // $rootScope get - pobiera dane użytkownika
      
      'getAvaibleProducts' : 'trade/getAvailableProducts',// trade get - dane do wypełnienia select w formularzu 
      
      'saveOrder' : 'trade/saveOrder',                    // trade post - wysyła zamówienie transakcji
      'loginSubmit' : 'login/submit'                      // login post - wysyła dane z formularza zamówiania
    },
    'messages': {
      'invalidLogin': 'User is not authorized. You have to register first.',
      'invalidPassword': 'Invalid password. Please try again.',

      'successTrade': 'You can see your order in dashboard.',
      'insufficentFunds': 'Sorry but you have no sufficent funds.',
      'insufficentProducts': 'Not sufficent volume of product.',
      'unexpectedError': 'Unexpected error occurs. Please try later.'
    }
  });

  // Define templates od angular material
  app.config(function ($mdThemingProvider) {
      $mdThemingProvider.theme('default')
        .primaryPalette('grey')
        .accentPalette('indigo')
        .backgroundPalette('grey')
        .warnPalette('red');
      $mdThemingProvider.theme('error')
        .primaryPalette('red')
        .accentPalette('deep-orange')
        .backgroundPalette('grey')
        .warnPalette('blue');
      $mdThemingProvider.theme('warning')
        .primaryPalette('orange')
        .accentPalette('deep-orange')
        .backgroundPalette('grey')
        .warnPalette('blue');
      $mdThemingProvider.theme('info')
        .primaryPalette('blue')
        .accentPalette('deep-orange')
        .backgroundPalette('grey')
        .warnPalette('blue');
      $mdThemingProvider.theme('success')
        .primaryPalette('green')
        .accentPalette('deep-orange')
        .backgroundPalette('grey')
        .warnPalette('blue');
    });

  app.config(function($httpProvider) {
     $httpProvider.interceptors.push('errorInterceptor');
  });

})();
