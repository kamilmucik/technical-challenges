

describe('Test of dialog service', function () {
  'use strict';
  var dialogService = {};
  var $mdDialog;
  
  beforeEach(module('juniorProject'));

  beforeEach(inject(function(_dialogService_, _$mdDialog_) {
    dialogService = _dialogService_;
    $mdDialog = _$mdDialog_;

  }));
  it('Test presence of dialogService', function () {
    expect(dialogService).toBeDefined();
  });

  it('A spy of showDialog method', function () {
    
    spyOn(dialogService, 'showDialog');
    dialogService.showDialog();
    
    expect(dialogService.showDialog).toHaveBeenCalled();
  });

  it('A spy of showDialog method which werify arguments', function () {
    
    spyOn(dialogService, 'showDialog');
    dialogService.showDialog('bar','foo');
    
    expect(dialogService.showDialog).toHaveBeenCalledWith('bar','foo');
  });  


});