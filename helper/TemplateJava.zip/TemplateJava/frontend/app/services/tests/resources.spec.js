'use strict';

describe('Test resources service', function() {
  var resourcesService = {};
  var $httpBackend;

    
  beforeEach(module('juniorProject'));


  beforeEach(inject(function(_resourcesService_, _$httpBackend_) {
    resourcesService = _resourcesService_;
    $httpBackend = _$httpBackend_;

  }));

  it('Test presence of service resourcesService', function () {
    expect(resourcesService).not.toBe(null);
  });



  beforeEach(function () {
    $httpBackend.when('GET', /\.html$/).respond('');
  });


  it('Testing makeRequest GET method',function () {
    var response;
    var dataOwnedAssets = {};
    
    $httpBackend.when('GET', 'http://10.200.202.108:8082/getOwnedAssets')
      .respond(200, dataOwnedAssets);

    resourcesService.makeRequest('getOwnedAssets').get()
    .$promise.then(function (data) {
        response = data;
      });
  
    $httpBackend.flush();
    expect(response).toBeDefined();
  });
  
  it('Testing makeRequest GET method with query parameter',function () {
    var response;
    var dataOwnedAssets = [];
    
    $httpBackend.when('GET', 'http://10.200.202.108:8082/getOwnedAssets')
      .respond(200, dataOwnedAssets);

    resourcesService.makeRequest('getOwnedAssets').query()
    .$promise.then(function (data) {
        response = data;
      });
  
    $httpBackend.flush();
    expect(response.length).toBe(0);
  });

  it('Testing makeRequest POST method',function () {
    var response;
    var request = {
      "login": "arek",
      "password": "arekPassword"
    };
    
    $httpBackend.when('POST', 'http://10.200.202.108:8082/login/submit')
      .respond(200, 'OK');

    resourcesService.makeRequest('login/submit').save(request)
      .$promise.then(function (data) {
        response = data;
      });
  
    $httpBackend.flush();
    expect(response).toBeDefined('OK');
  });

});
