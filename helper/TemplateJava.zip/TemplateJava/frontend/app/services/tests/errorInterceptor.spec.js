'use strict';

describe('Test of errorInterceptor', function () {
var errorInterceptor = {};

  beforeEach(module('juniorProject'));

  beforeEach(inject(function(_errorInterceptor_) {
    errorInterceptor = _errorInterceptor_;
    

  }));
  it('Return objects with 2 keys', function () {
    expect(Object.keys(errorInterceptor).length).toBe(2);
  });

  it('requestError interceptor parameter', function () {
    // var dialogService;
    var request = {
      statusText: 'bar',
      status: 'foo',
      config: {
        url: 'boo'
      }
    };
    // var requestErrorReturn = errorInterceptor()
    expect(errorInterceptor.requestError(request)).toBe(request);
  });

  it('responseError interceptor parameter', function () {
    // var dialogService;
    var rejection = {
      statusText: 'bar',
      status: 'foo',
      config: {
        url: 'boo'
      }
    };
    // var requestErrorReturn = errorInterceptor()
    expect(errorInterceptor.responseError(rejection)).toBe(rejection);
  });


});