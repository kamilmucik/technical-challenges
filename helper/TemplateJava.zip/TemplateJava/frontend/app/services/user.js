(function () {
  'use strict';
  var app = angular.module('juniorProject');

  app.service('userService', [
    '$rootScope',
    'resourcesService',
    'appConfig',
    function($rootScope, resourcesService, appConfig){

      var self = this;
      this.userData = {};


      this.getUser = function () {
        // console.log(Object.keys(self.userData).length === 0);
        resourcesService.makeRequest(appConfig.endPoints.getUser).get()
        .$promise.then(function (response) {
          self.userData = response;
          // Event globalny do dystrybucji danych użytkownika
          $rootScope.$broadcast(self.userData);
        });
      };

        
  }]);
})();