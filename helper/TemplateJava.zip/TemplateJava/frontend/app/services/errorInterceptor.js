(function () {
  'use strict';
  var app = angular.module('juniorProject');

  app.factory('errorInterceptor', [
    '$injector',
    // '$state',
    function($injector){
    return {
      requestError: function (request) {
        // console.log('errorinterceptor request error',request);
        // Use $injector allow to introduce errorDialogService without Circular dependency found: $http error
        var dialogService = $injector.get('dialogService');
        dialogService.showDialog('error', request.statusText + ' ' + request.config.url, request.status);
        return request;
      },
      responseError: function (rejection) {

        var dialogService = $injector.get('dialogService');
        var errorService = $injector.get('errorService');
        var state = $injector.get('$state');
        if (state.current.name === 'login') {
          return rejection;
        } else if (rejection.status === 401) {
          errorService.unAuth();
          return rejection;
        }
        else {
          dialogService.showDialog('error', rejection.statusText + ' ' + rejection.config.url, rejection.status);
          return rejection;
        }
        
      }
    };
  }]);
})();