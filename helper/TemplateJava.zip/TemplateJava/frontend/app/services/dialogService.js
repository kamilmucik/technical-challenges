(function () {
  'use strict';

  var app = angular.module('juniorProject');

  app.service('dialogService', [
    '$mdDialog',
    '$state',
    function($mdDialog, $state){  

      this.showDialog = function (type, content, status) {
        var title;
        var buildDialog;
        switch (type) {
          case 'error':
            title = 'Error!';
            break;
          case 'warning':
            title = 'Warning!';
            status = '';
            break;
          case 'success':
            title = 'Success!';
            status = '';
            break;
        }

        buildDialog = $mdDialog.alert()
          .clickOutsideToClose(true)
          .title(title + ' ' + status)
          .textContent(content)
          .ariaLabel(content)
          .ok('Close')
          .theme(type);
        
        return $mdDialog.show(buildDialog);
      };

    }
  ]);
})();