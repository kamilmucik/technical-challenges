(function () {
    'use strict';

    var app = angular.module('juniorProject');
  
    app.service('resourcesService', [
      '$resource',
      'appConfig',
      function($resource, appConfig) {
        
        this.makeRequest = function (endPoint, urlData) {
          return $resource(appConfig.baseURL + endPoint, urlData ,{
            get: {
              method: 'GET',
              // interceptor: errorInterceptor
            },
            query: {
              method: 'GET',
              isArray: true,
            },
            save: {
              method: 'POST',
            }
          });
        };
      }
    ]);

})(); 