(function () {
  'use strict';
  var app = angular.module('juniorProject');

  app.service('errorService', [
    '$state',
    function($state){  
      this.unAuth = function () {
        // console.log('routing to login');
        return $state.go('login', {});
      };
    }
  ]);
})();