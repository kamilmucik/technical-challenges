(function () {
  'use strict';
  var app = angular.module('juniorProject');

  app.service('dashboardDataService', [
   
    function(){

      // var self = this;
      this.dataAssets = {};


        
  }]);
})();