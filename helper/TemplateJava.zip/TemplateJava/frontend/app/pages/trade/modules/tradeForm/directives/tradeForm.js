(function(){
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Trade.tradeForm');
  app.directive('tradeTradeform', function () {
    return {
      templateUrl: 'pages/trade/modules/tradeForm/views/tradeForm.html',
      controller: 'tradeFormCtrl'
    };
  });
})();

