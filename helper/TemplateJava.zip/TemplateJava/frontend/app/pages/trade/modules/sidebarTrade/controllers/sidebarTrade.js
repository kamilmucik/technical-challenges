(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Trade.Sidebar');

  app.controller('sidebarTradeCtrl', [
    '$scope', 
    'tradeService',
    '$state',
    'userService',
    '$q',
    function ($scope, tradeService, $state, userService, $q) {
      
      $scope.inputFeatureModel = tradeService.inputFeatureModel;
      
      // Przejęcie eventu z danymi użytkownika
      $scope.$on(userService.userData, function (event, args) {
        $scope.inputFeatureModel.resources = event.name.availableFunds;
      });

      $scope.inputFeatureModel.resources = userService.userData.availableFunds;
      
      // Update price w sidebar
      var updateFeatureData = function (id) {
        // Wartości z formularza przychodzą w postaci string i trezeba je zamienić
        id = parseInt(id);
        // Aktualizacja obiektu w controlerze i w servisie ponieważ nie działało mi dostanie się w templatce do obiektu w serwisie
        tradeService.requestData.productId = id;
        for (var i = 0; i < tradeService.dataFormSelect.length; i++) {
          if (tradeService.dataFormSelect[i].id === id) {
            tradeService.inputFeatureModel.price = tradeService.dataFormSelect[i].price;
            break;
          } 
        }
      };


      $scope.$watch(function () {
        // Obserwowanie obiektu w serwisie który przejmuje dane z select
        return tradeService.inputFeatureModel.id;
      }, function (newValue, oldValue) {
        if (newValue && newValue !== oldValue) {
          // newValue = JSON.parse(newValue);
          updateFeatureData(newValue);

        }
      }, true); 

    }
  ]);
})();