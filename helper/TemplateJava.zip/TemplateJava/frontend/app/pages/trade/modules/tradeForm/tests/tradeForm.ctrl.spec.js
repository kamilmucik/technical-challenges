'use strict';

describe('Test tradeFormCtrl', function () {
  var scope,
  state,
  resourcesService,
  tradeService,
  appConfig,
  // $mdDialog,
  dashboardDataService,
  dialogService,
  tradeFormCtrl;
  // var resourcesService = {};
  // var tradeService = {};


  beforeEach(function () {
    module('juniorProject');
    // module('App.Pages.Trade.tradeForm');

    // module(function ($provide) {
    //   $provide.value('dialogService', dialogService);
    //   // $provide.value('resourcesService', resourcesService);
    //   $provide.value('tradeService', tradeService);
    //   $provide.value('appConfig', appConfig);
    //   // $provide.value('$state', $state);
    //   $provide.value('dashboardDataService', dashboardDataService);
    // });
  });

  beforeEach(inject(function (_$controller_, _resourcesService_) {
    scope = {};
    scope.$watch = function () {
      return true;
    };
    resourcesService = _resourcesService_;
    state = {
      params: {
        id: null
      }
    };

    tradeFormCtrl = _$controller_('tradeFormCtrl', {$scope:scope, $state:state});
  }));

  it('Test presence of tradeFormCtrl', function () {
    expect(tradeFormCtrl).toBeDefined();
  });
});