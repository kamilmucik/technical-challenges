

(function(){
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Trade.Sidebar');
  app.directive('tradeSidebar', function () {
    return {
      templateUrl: 'pages/trade/modules/sidebarTrade/views/sidebarTrade.html',
      controller: 'sidebarTradeCtrl'
    };
  });
})();

