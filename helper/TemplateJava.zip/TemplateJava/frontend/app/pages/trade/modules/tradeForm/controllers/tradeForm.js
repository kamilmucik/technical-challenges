(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Trade.tradeForm');

  app.controller('tradeFormCtrl', [
    '$scope', 
    'resourcesService',
    'tradeService',
    'appConfig',
    'dialogService',
    '$state',
    'dashboardDataService',
    function ($scope, resourcesService, tradeService, appConfig, dialogService, $state, dashboardDataService) {
  

      // Element DOM z obliczną wartością transakcji
      var transactionValue = document.querySelector('#transactionValue');

      $scope.message_debet = false;
      $scope.noneNegativeNumbersOnly = '^[0-9]+\.*$';
      $scope.integerNumbersOnly = '^[0-9]+$';
      


      // Funkcja wysyłająca formularz POST
      $scope.tradeSubmit = function (data) {
        resourcesService.makeRequest(appConfig.endPoints.saveOrder).save(data)
        .$promise.then(function (response) {
          if (response.message === 'OK') {
            dialogService.showDialog('success', appConfig.messages.successTrade).
            then(function () {
              $state.go('dashboard', {});
            });
          } else if (response.message === 'INSUFFICIENT_FUNDS') {
            dialogService.showDialog('warning', appConfig.messages.insufficentFunds);
          } else if (response.message === 'NOT_ENOUGH_AMOUNT_OF_PRODUCT') {
            dialogService.showDialog('warning', appConfig.messages.insufficentProducts);
          } else if (response.message === 'UNEXPECTED_ERROR') {
            dialogService.showDialog('error', appConfig.messages.unexpectedError);
          }
        });
      };



      // Take care about routing with either routing with params or directly
      // Routing with params
      if ($state.params.id !== null) {
        // Clear list of elements from select 
        tradeService.dataFormSelect = [];

        // Search for element in dataAssets list matched to id
        var stateData;
        if ($state.params.orderType === 'SALE') {
          for (var i = dashboardDataService.dataAssets.length - 1; i >= 0; i--) {
            if (dashboardDataService.dataAssets[i].id === $state.params.id) {
              stateData = dashboardDataService.dataAssets[i];
              break;
            }
          }
        } else {
          console.log('Place to search in quotations TODO');
        }
        

        // Update data to select field in tradeForm
        $scope.updateDataFromSelect = function () {
          tradeService.dataFormSelect[0] = {
            id: stateData.id, 
            name: stateData.productName, 
            price: stateData.price
          };

          // Fill object in tradeService which is responsible for a proper select coplete
          tradeService.requestData = {
            productId: stateData.id,
            orderType: $state.params.orderType,
            price: stateData.price,
            volume: stateData.volume
          };

          // Update data of transaction_value
          tradeService.inputFeatureModel.transactionValueUpdate();

          // Default set query element selected in tradeForm and price updated
          tradeService.inputFeatureModel.id = tradeService.dataFormSelect[0].id;
          tradeService.inputFeatureModel.price = tradeService.dataFormSelect[0].price;
          
          // Object from tradeService linked to scope
          $scope.dataFormSelect = tradeService.dataFormSelect;
        };

        $scope.updateDataFromSelect();
       
        // Get elements from get request in case of directly ng-sref to trade url
      } else {
        resourcesService.makeRequest(appConfig.endPoints.getAvaibleProducts).get().
        $promise.then(function (response) {
          tradeService.dataFormSelect = response.content;
          $scope.dataFormSelect = tradeService.dataFormSelect;
        });
      }

      // Dodawanie obiektów z serwisu do scopea
      $scope.inputFeatureModel = tradeService.inputFeatureModel;
      $scope.requestData = tradeService.requestData;


      // Watch which compare transactoin_value to avaible resources in case od buy scenario
      $scope.$watch(function () {
        var inputFieldsWatch = {
            price: $scope.requestData.price,
            volume: $scope.requestData.volume,
            radioButton: $scope.requestData.orderType
          };
        return inputFieldsWatch;
      }, function (newValue, oldValue) {
        if (newValue && newValue !== oldValue) {
          tradeService.inputFeatureModel.transactionValueUpdate();
          if ($scope.requestData.orderType === 'SALE') {
            $scope.message_debet = false;
          }
          else if (tradeService.inputFeatureModel.transaction_value < tradeService.inputFeatureModel.resources) {
            // Etykieta pod transaction value i w formularzu
            $scope.message_debet = false;
          } else if ($scope.requestData.price === undefined || $scope.requestData.volume === undefined) {
            $scope.message_debet = false;
          }
          else {
            $scope.message_debet = true;
            transactionValue.setAttribute('class', 'validation-messages');
          }
        }
      }, true);


    }
  ]);
})();