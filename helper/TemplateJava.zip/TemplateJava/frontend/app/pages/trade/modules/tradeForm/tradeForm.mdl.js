(function(){
  'use strict';
  angular.module('App.Pages.Trade.tradeForm', []);
})();

