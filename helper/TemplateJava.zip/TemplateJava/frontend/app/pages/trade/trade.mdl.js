(function () {
	'use strict';
	// Define the `login` module
	angular.module('App.Pages.Trade', [
        // 'ngRoute',
        'ui.router',
        'App.Pages.Trade.Sidebar',
        'App.Pages.Trade.tradeForm',
        'App.Pages.Dashboard.Navbar'
    ]);
})();