(function () {
	'use strict';
	// Define the `phoneList` module
	var app = angular.module('App.Pages.Trade');

	app.config(['$stateProvider', function ($stateProvider) { // $stateProvider
		$stateProvider
			.state('trade', { // state
				url: '/trade/{id:int}',
				templateUrl: 'pages/trade/views/trade.html',
				controller: 'tradeCtrl',
				params: {id:null, orderType:null}
			});
	}]);
})();

