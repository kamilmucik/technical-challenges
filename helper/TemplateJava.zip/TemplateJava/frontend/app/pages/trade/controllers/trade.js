(function () {
    'use strict';

		var app = angular.module('App.Pages.Trade');

		app.controller('tradeCtrl', [
			'$scope', 
      'userService',
			function ($scope, userService) {
        userService.getUser();
      }
    ]);

})();	