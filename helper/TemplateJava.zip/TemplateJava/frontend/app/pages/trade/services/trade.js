(function () {
  'use strict';

  var app = angular.module('App.Pages.Trade');

  app.service('tradeService', function () {
    var self= this;
   // Obiekt przejmujący dane z listy rozwijanej formularza w postaci jsona jako tekstu
    this.inputFeatureModel = {
      id: null,
      resources: null,
      price: 0,
      transaction_value: 0,
      transactionValueUpdate : function () {
        this.transaction_value = self.requestData.price * self.requestData.volume;
        return this.transaction_value;
      }
      // cena nie ma się odejmować po stronie frontendu 
      // tradeCalc: function () {
      //   this.resources -= this.transaction_value;
      //   return this.resources;
      // }
    };

    // Obiekt do wysłania formularzem
    this.requestData = {
      productId: null,
      orderType: 'PURCHASE',
      price: null,
      volume: null
    };

    this.dataFormSelect = [];

  });
})();