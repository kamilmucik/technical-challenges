(function () {
	'use strict';
    // console.log('module');
	// Define the `login` module
	angular.module('App.Pages.History', [
        // 'ngRoute',
        'ui.router'
    ]);
})();