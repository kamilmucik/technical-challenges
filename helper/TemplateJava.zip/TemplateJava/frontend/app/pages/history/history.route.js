(function () {
	'use strict';
	// Define the `phoneList` module
	var app = angular.module('App.Pages.History');

	app.config(['$stateProvider', function ($stateProvider) { // $stateProvider
		$stateProvider
			.state('history', { // state
				url: '/history',
				templateUrl: 'pages/history/views/history.html',
				controller: 'historyCtrl'
			});
	}]);
})();

