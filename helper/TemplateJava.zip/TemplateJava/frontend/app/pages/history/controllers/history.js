(function () {
    'use strict';

		var app = angular.module('App.Pages.History');

		app.controller('historyCtrl', [
			'$scope', 
      'resourcesService',
      '$state',
      '$mdDialog',
      'appConfig',
			function ( $scope, resourcesService, $state, $mdDialog, appConfig) {
        var vm = this;

        vm.show = function () {};

        $scope.searchData = {
          'name': null,
          'fromDate':null,
          'toDate': null
        };

        $scope.submitSearch = function (searchData) {
          resourcesService.makeRequest(appConfig.endPoints.getMyAssets, searchData).get().
          $promise.then(function (response) {
            $scope.historyData = response.content;
          }, function (error) {
            return resourcesService.errorService(error.status, error.statusText);
          });
        };

        // @scope.watch

        $scope.historyData = [
        {
          "id": 5,
          "productName": "Goldaaaaa",
          "price": 4500,
          "volume": 50,
          "purchasePrice": 225000,
          "profit": 0.06,
          "purchaseDate": 1406109600000
        },
        {
          "id": 6,
          "productName": "Goldaaaa",
          "price": 3500,
          "volume": 10,
          "purchasePrice": 35000,
          "profit": 0.06,
          "purchaseDate": 1408788000000
        },
        {
          "id": 7,
          "productName": "Goldaaa",
          "price": 2500,
          "volume": 30,
          "purchasePrice": 75000,
          "profit": 0.06,
          "purchaseDate": 1411466400000
        },
        {
          "id": 8,
          "productName": "Palladiumaaa",
          "price": 1500,
          "volume": 60,
          "purchasePrice": 90000,
          "profit": 0.06,
          "purchaseDate": 1406109600000
        },
        {
          "id": 7,
          "productName": "Goldaaa",
          "price": 2500,
          "volume": 30,
          "purchasePrice": 75000,
          "profit": 0.06,
          "purchaseDate": 1411466400000
        },
        {
          "id": 8,
          "productName": "Palladiumaaa",
          "price": 1500,
          "volume": 60,
          "purchasePrice": 90000,
          "profit": 0.06,
          "purchaseDate": 1406109600000
        },
        {
          "id": 7,
          "productName": "Goldaaa",
          "price": 2500,
          "volume": 30,
          "purchasePrice": 75000,
          "profit": 0.06,
          "purchaseDate": 1411466400000
        },
        {
          "id": 8,
          "productName": "Palladiumaaa",
          "price": 1500,
          "volume": 60,
          "purchasePrice": 90000,
          "profit": 0.06,
          "purchaseDate": 1406109600000
        },
        {
          "id": 7,
          "productName": "Goldaaa",
          "price": 2500,
          "volume": 30,
          "purchasePrice": 75000,
          "profit": 0.06,
          "purchaseDate": 1411466400000
        },
        {
          "id": 8,
          "productName": "Palladiumaaa",
          "price": 1500,
          "volume": 60,
          "purchasePrice": 90000,
          "profit": 0.06,
          "purchaseDate": 1406109600000
        }
      ];
      

      }
    ]);
})();	