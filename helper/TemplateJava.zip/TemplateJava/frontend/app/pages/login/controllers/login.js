(function () {
    'use strict';

		var app = angular.module('App.Pages.Login');

		app.controller('loginCtrl', [
			'$scope', 
      'resourcesService',
      '$state',
      'dialogService',
      'appConfig',
			function ( $scope, resourcesService, $state, dialogService, appConfig) {

        $scope.dataLogin = {
          login: null,
          password: null
        };

        $scope.loginSubmit = function (data) {
          resourcesService.makeRequest(appConfig.endPoints.loginSubmit).save(data).
          $promise.then(function (response) {
            // console.log('success',response)
            if (response.message === 'OK') {
              $state.go('dashboard', {});
            } else if (response.message === 'INVALID_LOGIN') {
              dialogService.showDialog('warning', appConfig.messages.invalidLogin);
            } else if (response.message === 'INVALID_PASSWORD') {
              dialogService.showDialog('warning', appConfig.messages.invalidPassword);
            }
          });
        };
      }
    ]);
})();	