(function () {
	'use strict';
    // console.log('module');
	// Define the `login` module
	angular.module('App.Pages.Login', [
        // 'ngRoute',
        'ui.router'
    ]);

})();