(function () {
	'use strict';
	// Define the `phoneList` module
	var app = angular.module('App.Pages.Login');

	app.config(['$stateProvider', function ($stateProvider) { // $stateProvider
		$stateProvider
			.state('login', { // state
				url: '/login',
				templateUrl: 'pages/login/views/login.html',
				controller: 'loginCtrl'
			});
	}]);
})();

