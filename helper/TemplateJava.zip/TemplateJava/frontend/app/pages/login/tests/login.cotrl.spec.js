'use strict';

describe('Test loginCtrl', function() {
  var scope,
  resourcesService,
  loginCtrl,
  $state,
  appConfig,
  $injector,
  dialogService;

  beforeEach(function () {
    
    module('App.Pages.Login');
    // Tutaj deklarujesz dodatkowe zależności
    module(function ($provide) {
      $provide.value('dialogService', dialogService);
      $provide.value('resourcesService', resourcesService);
      $provide.value('appConfig', appConfig);
    });
  });
// console.log(dialogService)
  beforeEach(inject(function(_$controller_) {
    scope = {};
    loginCtrl = _$controller_('loginCtrl', { $scope: scope });
  }));

  it('Test presence of controller loginCtrl in module App.Pages.Login', function () {
    expect(loginCtrl).not.toBe(null);
  });

  it('Test of dataLogin object to have 2 keys',function () {
    expect(Object.keys(scope.dataLogin).length).toBe(2);
  });

});
