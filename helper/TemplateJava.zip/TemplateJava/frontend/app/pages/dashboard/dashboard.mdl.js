(function () {
	'use strict';

	// Define the `dashboard` module
	angular.module('App.Pages.Dashboard', [
        'ui.router',
        'smart-table',
        'ngResource',
        'App.Pages.Dashboard.ActiveOrder',
        'App.Pages.Dashboard.Assets',
        'App.Pages.Dashboard.Chart',
        'App.Pages.Dashboard.Quotations',
        'App.Pages.Dashboard.Navbar',
        'App.Pages.Dashboard.Sidebar'
        // 'navbarCtrl'
        // 'App.Pages.Dasboard.Nav'
    ]);
})();