(function () {
	'use strict';

	// Define the `dashboard` module
	var app = angular.module('App.Pages.Dashboard');

	app.config(['$stateProvider', function ($stateProvider) { 
		$stateProvider
			.state('dashboard', {
				url: '/dashboard',
				templateUrl: 'pages/dashboard/views/dashboard.html',
				controller: 'dashboardCtrl as dashboardVM'
			});
	}]);
})();

