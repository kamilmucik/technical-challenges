(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Dashboard.Assets');

  app.controller('assetsCtrl', [
    '$scope', 
    'resourcesService',
    'appConfig',
    '$state',
    'dashboardDataService',
    function ($scope, resourcesService, appConfig, $state, dashboardDataService) {

      

      resourcesService.makeRequest(appConfig.endPoints.getMyAssets).get().
      $promise.then(function (response) {
        // $scope.dataAssets = response.content;
        dashboardDataService.dataAssets = response.content;
        $scope.dataAssets = dashboardDataService.dataAssets;
      });

      $scope.sellItem = function sellItem(row) {
        // console.log(row); 
        $state.go('trade', {id:row.id, orderType:'SALE'});
      };

      $scope.multiply = function (feat) {
        return feat.price * feat.volume;
      };
    }
  ]);
})();