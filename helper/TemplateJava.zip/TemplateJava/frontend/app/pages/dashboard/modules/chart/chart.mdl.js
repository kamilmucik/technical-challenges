
(function() {
  'use strict';

  angular.module('App.Pages.Dashboard.Chart', [
    'angularCharts'
  ]);
})();

