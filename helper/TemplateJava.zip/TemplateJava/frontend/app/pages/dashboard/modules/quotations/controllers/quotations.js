(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Dashboard.Quotations');

  app.controller('quotationsCtrl', [
    '$scope', 
    'resourcesService',
    'appConfig',
    function ($scope, resourcesService, appConfig) {
      
      // resourcesService.makeRequest(appConfig.endPoints.getQuotations).get().
      // $promise.then(function (response) {
      //   $scope.dataQuotations = response;
      // });

      // Mock data till backend serve a proper endpoint
      $scope.dataQuotations = [
        {"id":1,"name":"Gold","price":100.00},
        {"id":2,"name":"Palladium","price":150.00},
        {"id":3,"name":"Platinum","price":160.00},
        {"id":4,"name":"Silver","price":80.00},
        {"id":5,"name":"T-Bill","price":50.00},
        {"id":6,"name":"T-Note","price":30.00},
        {"id":7,"name":"T-Bond","price":75.00}
      ];

      $scope.buyItem = function buyItem(row) {
        console.log(row); 
      };


    }
  ]);
})();
