

(function(){
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Dashboard.Quotations');
  app.directive('dashboardQuotations', function () {
    return {
      templateUrl: 'pages/dashboard/modules/quotations/views/quotations.html',
      controller: 'quotationsCtrl'
    };
  });
})();

