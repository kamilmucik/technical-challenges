

(function(){
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Dashboard.Assets');

  app.directive('dashboardAssets', function() {
    return {
      templateUrl: 'pages/dashboard/modules/assets/views/assets.html',
      controller: 'assetsCtrl'
      // controllerAs: 'assetsCtrlMV'
        
      
    };
  });
})();

