
(function() {
  'use strict';
  angular.module('App.Pages.Dashboard.Sidebar', []);
})();

