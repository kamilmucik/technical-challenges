(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Dashboard.Chart');

  app.controller('chartCtrl', [
    '$scope', 
    'resourcesService',
    'appConfig',
    function ($scope, resourcesService, appConfig) {
    
      // resourcesService.makeRequest(appConfig.endPoints.getResources).get().
      // $promise.then(function (response) {
      //   $scope.dataChart = response;
      // });
      
      // Mock data till backend serve a proper endpoint
      $scope.dataChart = {
        "series": ["Total Resources", "Income", "Expense"],
        "data": [
          {
            "x": ["Jun"],
            "y": [1400, 700, 300]
          }, {
            "x": ["Feb"],
            "y": [1500, 600, 500]
          }, {
            "x": ["Mar"],
            "y": [1600, 1000, 900]
          },
          {
            "x": ["Apr"],
            "y": [1500, 500, 600]
          },
          {
            "x": ["May"],
            "y": [2000, 1000, 500]
          },
          {
            "x": ["June"],
            "y": [2200, 800, 600]
          },
          {
            "x": ["July"],
            "y": [2500, 500, 200]
          }
        ]
      };


      $scope.config = {
        // title: 'Products',
        tooltips: true,
        labels: false,
        mouseover: function() {

        },
        mouseout: function() {},
        click: function() {},
        legend: {
          display: false,
          //could be 'left, right'
          position: 'right'
        },
        innerRadius: 0, // applicable on pieCharts, can be a percentage like '50%'
        lineLegend: 'traditional' // can be also 'lineEnd', 'traditional'
      };
      

    }
  ]);
})();
