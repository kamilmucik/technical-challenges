(function(){
    'use strict';
    // var dashboardNav = angular.module('App.Pages.Dashboard');
    angular.module('App.Pages.Dashboard.Navbar', []);
})();
