(function() {
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Dashboard.ActiveOrder');

  app.directive('dashboardActiveOrder', function () {
    return {
      templateUrl: 'pages/dashboard/modules/activeOrder/views/activeOrder.html',
      controller: 'activeOrderCtrl'
    };
  });
})();

