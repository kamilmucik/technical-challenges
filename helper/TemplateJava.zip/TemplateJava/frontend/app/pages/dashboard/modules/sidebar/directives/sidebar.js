

(function(){
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Dashboard.Sidebar');
  app.directive('dashboardSidebar', function () {
    return {
      templateUrl: 'pages/dashboard/modules/sidebar/views/sidebar.html',
      controller: 'sidebarCtrl'
    };
  });
})();

