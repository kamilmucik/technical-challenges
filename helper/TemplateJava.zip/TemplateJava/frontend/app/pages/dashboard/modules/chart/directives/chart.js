(function(){
  'use strict';
  // var dashChartActive = angular.module('App.Pages.Dashboard', []);
  var app = angular.module('App.Pages.Dashboard.Chart');
  app.directive('dashboardChart', function () {
    return {
      templateUrl: 'pages/dashboard/modules/chart/views/chart.html',
      controller: 'chartCtrl'
      // link: function (scope, elem, attrs) {
        
      // }   
    };
  });
})();

