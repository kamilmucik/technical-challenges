(function(){
  'use strict';
  // var dashboardNav = angular.module('App.Pages.Dashboard');
  var app = angular.module('App.Pages.Dashboard.Navbar');
  app.directive('dashboardNavbar', function () {
    return {
      controller: 'navbarCtrl',
      templateUrl: 'pages/dashboard/modules/navbar/views/navbar.html'
    };
  });
})();
