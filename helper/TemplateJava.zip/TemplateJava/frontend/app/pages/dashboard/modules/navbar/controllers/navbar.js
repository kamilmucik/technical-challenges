(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Dashboard.Navbar');

  app.controller('navbarCtrl', [
    '$scope', 
    'userService',
    '$state',
    function ($scope, userService, $state) {

     $scope.logout = function () {
      userService.userData = {};
      return $state.go('login', {});
     };
     // userService.purgeUserData;

      $scope.$on(userService.userData, function (event, args) {
        $scope.userName = event.name.login;
      });
      
    }
  ]);
})();