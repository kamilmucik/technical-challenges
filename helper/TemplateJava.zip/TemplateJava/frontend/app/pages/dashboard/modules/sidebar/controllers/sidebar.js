(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Dashboard.Sidebar');

  app.controller('sidebarCtrl', [
    '$scope', 
    'userService',
    function ($scope, userService) {

      $scope.$on(userService.userData, function (event, args) {
        $scope.dataSidebar = event.name;
      });
    }
  ]);
})();
