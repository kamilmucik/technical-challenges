(function () {
  'use strict';
  
  var app = angular.module('App.Pages.Dashboard.ActiveOrder');

  app.controller('activeOrderCtrl', [
    '$scope',
    'resourcesService',
    'appConfig',
    function ($scope, resourcesService, appConfig) {


      resourcesService.makeRequest(appConfig.endPoints.getActiveOrders).get().
      $promise.then(function (response) {
        $scope.dataActiveOrder = response.content;
      });

      $scope.multiply = function (feat) {
        return feat.price * feat.volume;
      };

      $scope.removeItem = function removeItem(row) {
        var index = $scope.dataActiveOrder.indexOf(row);
        if (index !== -1) {
            $scope.dataActiveOrder.splice(index, 1);
        }
      };

      $scope.editItem = function editItem(row) {
        console.log(row); 
      };
      
    }
  ]);
})();
