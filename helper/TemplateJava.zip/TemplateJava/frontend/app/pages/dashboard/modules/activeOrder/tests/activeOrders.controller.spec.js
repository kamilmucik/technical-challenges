'use strict';

describe('Test activeOrderCtrl', function() {
  var scope;
  var resourcesService;
  var activeOrderCtrl;


  beforeEach(function () {
    module('juniorProject');

  });

  beforeEach(inject(function(_$controller_, _resourcesService_) {
    scope = {};
    resourcesService = _resourcesService_;

    activeOrderCtrl = _$controller_('activeOrderCtrl', { $scope: scope});
   
  }));

  it('Test presence of controller activeOrderCtrl in module App.Pages.Dashboard.ActiveOrder', function () {
    expect(activeOrderCtrl).not.toBe(null);
  });

  it('Test multiply method',function () {

    var feature = {
      price: 10,
      volume: 10
    };

    expect(scope.multiply(feature)).toBe(100);
  });



});