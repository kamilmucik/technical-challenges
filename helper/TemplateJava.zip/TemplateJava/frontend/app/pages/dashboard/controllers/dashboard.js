(function () {
  'use strict';

	var app = angular.module('App.Pages.Dashboard');

	app.controller('dashboardCtrl', [
   	'$scope', 
    'resourcesService',
    'userService',
		function ($scope, resourcesService, userService) {
     
      var vm = this;
      
      vm.show = function () {};
      
      userService.getUser(); 
      

    }

  ]);

})();	