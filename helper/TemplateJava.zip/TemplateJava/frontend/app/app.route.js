(function () {
  'use strict';
  angular.
  module('juniorProject').
  config(['$stateProvider', '$urlRouterProvider',
    function config($stateProvider, $urlRouterProvider) {
      // $locationProvider.hashPrefix('!');
      $urlRouterProvider.otherwise('/login');

    }
  ]);
})();



