(function () {
  'use strict';
module.exports = function(grunt) {

  // do requires here
  // Time how long tasks take. Can help when optimazing build times.
  require('time-grunt')(grunt);

  // Automatically load required Grunt tasks
  require('jit-grunt')(grunt, {
    useminPrepare: 'grunt-usemin'
  });

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),



///////////////////////////////////////////////////////////
/// Build process ///


    // Removes all files and folders with the src folder!!!
    clean: {
      build: {
        src: [ 'dist/']
      }
    },

    // Check if js files don't have any syntax bugs
    jshint: {
      options: {
        jshintrc: '.jshintrc',

        reporter: require('jshint-stylish')
      },
      all: {
        src: [
          '**/.jshintrc',
          'Gruntfile.js',
          'app/**/*.js',
          '!**/bower_components/**/*.js',
          '!**/coverage/**/*.js',
          '!**/*.spec.js'
        ]
      }
    },

    // Convert sass (scss) to css 
    sass: {                              // Task
      dist: {                            // Target
        options: {                       // Target options
          style: 'compressed'            // expanded
        },
        files: {                         // Dictionary of files
          'app/assets/styles/main.css': 'app/assets/styles/main.scss'       // 'destination': 'source'
        }
      }
    },

    // Dependency od usemin module. Prepares blocks in html index file. 
    useminPrepare: {
      html: 'app/index.html',
      options: {
        dest: 'dist'
      }
    },


    // Concating all javascript and css. That mean that createc one line enstead of block file.
    concat: {
      options: {
        separator: ';',

      },
      // dist configuration is provided by useminPrepare
      dist: {}
    },

    // Minify css files
    cssmin: {
      dist: {}
    },


    // Uglify
    uglify: {
      options: {
        // Doesn't change variables and functions names. This caused an error. 
        mangle: false
      },
      // dist configuration is provided by useminPrepare
      dist: {}
    },

    copy: {
      dist: {
        cwd: 'app',
        src: [ 
          'index.html', 
          'pages/**/*.html', 
          'img/icons/**/*.svg', 
          '!**/*.css',
          '!**/*.js' 
        ],
        dest: 'dist',
        expand: true
      },
      
      fonts: {
        files: [
          {
            //for bootstrap fonts
            expand: true,
            dot: true,
            cwd: 'bower_components/bootstrap/dist',
            src: ['fonts/*.*'],
            dest: 'dist'
          }, {
            //for font-awesome
            expand: true,
            dot: true,
            cwd: 'bower_components/font-awesome',
            src: ['fonts/*.*'],
            dest: 'dist'
          }
        ]
      }
    },

    // Filerev
    filerev: {
      options: {
        encoding: 'utf8',
        algorithm: 'md5',
        length: 20
      },
      release: {
        // filerev:release hashes(md5) all assets (images, js and css )
        // in dist directory
        files: [{
          src: [
            'dist/scripts/*.js',
            'dist/styles/*.css',
          ]
        }]
      }
    },
      

    // Usemin
    // Replaces all assets with their revved version in html and css files.
    // options.assetDirs contains the directories for finding the assets
    // according to their relative paths
    usemin: {
      html: ['dist/*.html'],
      css: ['dist/styles/*.css'],
      options: {
        assetsDirs: ['dist', 'dist/styles']
      }
    },


///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////





    connect: {
      options: {
        // port: 9000,
        livereload: true,// 35729
        // Change this to '0.0.0.0' to access the server from outside.
        hostname: 'localhost'
      },
      dev: {
        options: {
          port: 9000,
          open: true,
          base:{
            path: 'app',
            options: {
              index: 'index.html'
              // maxAge: 300000
            }
          }
        }
      },
      dist: {
        options: {
          port: 9002,
          open: true,
          base:{
            path: 'dist',
            options: {
              index: 'index.html'
              // maxAge: 300000
            }
          }
        }
      }
    },



    karma: {
      continous: {
        configFile: 'karma.conf.js',
        singleRun: false
      },
      //continuous integration mode: run tests once in PhantomJS browser.
      single: {
        configFile: 'karma.conf.js',
        options : {
          singleRun: true
        }
      }
    },


    watch: {
      
      styles: {
        files: ['app/**/*.scss'],
        tasks:['sass'],
        options: {
          livereload: true
        }
      },

      livereload: {
        options: {
          livereload: '<%= connect.options.livereload %>'
        },   
        files: [
          'app/**/*.html',
          'app/**/*.css',
          'app/**/*.js',
          'app/images/{,*/}*.{png,jpg,jpeg,gif,webp,svg}'
        ]
      },

    }

  });

  grunt.registerTask('build', [
    'clean',
    'sass',
    'useminPrepare',
    'concat',
    'cssmin',
    'uglify',
    'copy',
    // 'copy:fonts',
    'filerev',
    'usemin'
    ]);

  grunt.registerTask('serve', ['connect:dev','watch']);

  grunt.registerTask('default', ['build']);

  grunt.registerTask('test-single', ['karma:single']);

  grunt.registerTask('test', ['karma:continous']);
};
})();