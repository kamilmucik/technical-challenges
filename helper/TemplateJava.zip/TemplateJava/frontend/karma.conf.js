// Karma configuration
// Generated on Wed Aug 03 2016 17:00:20 GMT+0200 (W. Europe Daylight Time)

module.exports = function(config) {
  config.set({

    // base path that will be used to resolve all patterns (eg. files, exclude)
    basePath: 'app/',

    // preprocess matching files before serving them to the browser
    // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
    preprocessors: {
        '**/*.js': ['coverage']
        // '**/*.html': ['ng-html2js']
    },

    // frameworks to use
    // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
    frameworks: ['jasmine'], //, 'requirejs'


    // list of files / patterns to load in the browser
    files: [
 
    'bower_components/angular/angular.js',
    "bower_components/angular-ui-router/release/angular-ui-router.js",
    'bower_components/angular-mocks/angular-mocks.js',
    "bower_components/angular-resource/angular-resource.js",
    "bower_components/angular-ui-router/release/angular-ui-router.js",

    "bower_components/angular-animate/angular-animate.js",
    "bower_components/angular-aria/angular-aria.js",
    "bower_components/angular-messages/angular-messages.js",
    "bower_components/angular-material/angular-material.js",
    "bower_components/angular-smart-table/dist/smart-table.min.js",

    "bower_components/d3/d3.js",
    "bower_components/angular-charts/dist/angular-charts.min.js",

    "app.module.js",
    "pages/login/login.mdl.js",
    "pages/dashboard/dashboard.mdl.js",
    "pages/trade/trade.mdl.js",
    
    "pages/dashboard/modules/activeOrder/activeOrder.mdl.js",
    "pages/dashboard/modules/assets/assets.mdl.js",
    "pages/dashboard/modules/chart/chart.mdl.js",
    "pages/dashboard/modules/navbar/navbar.mdl.js",
    "pages/dashboard/modules/quotations/quotations.mdl.js",
    "pages/dashboard/modules/sidebar/sidebar.mdl.js",
    
    "pages/trade/modules/sidebarTrade/sidebarTrade.mdl.js",
    "pages/trade/modules/tradeForm/tradeForm.mdl.js",

    "pages/history/history.mdl.js",


    "pages/dashboard/modules/activeOrder/directives/activeOrder.js",
    "pages/dashboard/modules/assets/directives/assets.js",
    "pages/dashboard/modules/chart/directives/chart.js",
    "pages/dashboard/modules/navbar/directives/navbar.js",
    "pages/dashboard/modules/quotations/directives/quotations.js",
    "pages/dashboard/modules/sidebar/directives/sidebar.js",

    "pages/trade/modules/sidebarTrade/directives/sidebarTrade.js",
    "pages/trade/modules/tradeForm/directives/tradeForm.js",


    "pages/dashboard/controllers/dashboard.js",
    "pages/dashboard/modules/assets/controllers/assets.js",
    "pages/dashboard/modules/chart/controllers/chart.js",
    "pages/dashboard/modules/quotations/controllers/quotations.js",
    "pages/dashboard/modules/sidebar/controllers/sidebar.js",
    "pages/dashboard/modules/activeOrder/controllers/activeOrder.js",
    "pages/dashboard/modules/navbar/controllers/navbar.js",

    "pages/trade/controllers/trade.js",
    "pages/trade/modules/sidebarTrade/controllers/sidebarTrade.js",
    "pages/trade/modules/tradeForm/controllers/tradeForm.js",
    "pages/login/controllers/login.js",

    "pages/history/controllers/history.js",

    // Services go here
    
    "services/resources.js",
    "services/user.js",
    "services/errorInterceptor.js",
    "services/dialogService.js",
    "services/errorService.js",
    "services/dashboardDataService.js",

    "pages/trade/services/trade.js",
    

    "filters/myFilters.js",


    "pages/login/login.route.js",
    "pages/dashboard/dashboard.route.js",
    "pages/trade/trade.route.js",

    "app.route.js",

    
    'services/**/*spec.js',
    'pages/dashboard/**/*spec.js',
    'pages/trade/**/*spec.js',
    'pages/login/**/*spec.js'

    ],


    // list of files to exclude
    exclude: [
    ],


  


    // test results reporter to use
    // possible values: 'dots', 'progress'
    // available reporters: https://npmjs.org/browse/keyword/karma-reporter
    reporters: ['progress', 'coverage'], //, 'coverage'

    coverageReporter : {
      type: 'text',
      dir: 'coverage/',
      file: 'coverage.txt'
    },
    // web server port
    port: 9876,


    // enable / disable colors in the output (reporters and logs)
    colors: true,


    // level of logging
    // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
    logLevel: config.LOG_INFO,


    // enable / disable watching file and executing tests whenever any file changes
    autoWatch: true,


    // start these browsers
    // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
    browsers: ['PhantomJS'], //'Chrome', 'Firefox', 'PhantomJS'

    // plugins : [
    //   // 'karma-chrome-launcher',
    //   'karma-jasmine',
    //   'karma-ng-html2js-preprocessor',
    //   // 'karma-requirejs',
    //   'karma-phantomjs-launcher'
    //   // 'karma-coverage'
    //   // 'karma-chai'
    // ],


    // Continuous Integration mode
    // if true, Karma captures browsers, runs the tests and exits
    // singleRun: false,

    // Concurrency level
    // how many browser should be started simultaneous
    concurrency: Infinity,

    // 2 minutes wait until abort browser. Impotant for single run mode
    browserNoActivityTimeout: 120000
  });
};
