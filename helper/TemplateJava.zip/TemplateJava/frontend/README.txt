Junior Projekt Front-end
Piotr Szukała


Front end jest oparty na frameworku Angular 1.5 i wykorzystuje nodejs w wersji deweloperskiej. Żeby uruchomić frontend trzeba mieć zaintalowanego NODEJS

1) Żeby ściągnąć branche'a frontend należy w konsoli wykonać polecenie git: 
git clone -b frontend git@git.gft.com:azws/TemplateJava.git

2) Po ściągnięciu plików należy przejsć do tej lokalizacji 
cd frontend

3) Następnie należy ściągnąc zalezności nodejs za pomocą taskrunnera grunt 
grunt run preinstall 
Utworzy się folder node_modules

4) Następnie musimy ściągnąć zależności samej aplikacji 
grunt run postinstall 
utworzy się folder bower_components w folderze app

4) front-end może działać w zmokowanej formie i trzeba wystartować mock serwer ze sztucznymi danymi
cd mock-backend
node index.js

5) Teraz trzeba wystartować serwer do uruchomienia front-endu
w folderze frontend 
grunt serve