var tradePage = require('../pages/trade');

describe('Project Junior trade page',function () {
  // Testy idą tutaj....  


});