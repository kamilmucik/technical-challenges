var dashboardPage = require('../pages/dashboard');

describe('Project Junior dashboard page',function () {
  // Testy idą tutaj....  


});