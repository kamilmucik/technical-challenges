var loginPage = require('../pages/login');
//var homePage = require('../pages/home.example');

describe('Project Junior login page', function() {

	beforeEach(function () {
		loginPage.get();
	});

	it('title should be Project Junior', function(){
		expect(loginPage.getTitle()).toEqual("Project Junior");
	});

	it('Button shoul be submit type', function(){
		expect(loginPage.loginButton.getAttribute('type')).toEqual("submit");
	});

	it('Should refuse login to dashboard page after incorrect login and password', function () {
		var login = loginPage.inputLogin.clear().sendKeys('wrongLogin');
		var pass = loginPage.inputPassword.clear().sendKeys('wrongPassworda');
		loginPage.clickLoginButton();
		// Określa czy przeglądarka ma czekać na rozwiązanie promise czy nie. W tym przypadku czeka i wykona test dopiero jak strona się załaduje
		browser.ignoreSynchronization = false;
		expect(browser.getCurrentUrl()).toContain('login');
	});

	it('Should login to dashboard page after correct login and password', function () {
		var login = loginPage.inputLogin.clear().sendKeys('arek');
		var pass = loginPage.inputPassword.clear().sendKeys('arekPassword');
		loginPage.clickLoginButton();
		// Określa czy przeglądarka ma czekać na rozwiązanie promise czy nie. W tym przypadku czeka i wykona test dopiero jak strona się załaduje
		browser.ignoreSynchronization = false;
		expect(browser.getCurrentUrl()).toContain('dashboard');
	});

});
