var TradePage = function () {
  // Definicja buttona 'Order goods'
  this.tradeformSelect = element(by.css('.tradeform select'));
  this.tradeformBuy = element(by.css('.tradeform input[value="0"]'));
  this.tradeformSell = element(by.css('.tradeform input[value="1"]'));
  this.tradeformAmount = element(by.css('.tradeform input[placeholder="Amount"]'));
  this.tradeformQuantity = element(by.css('.tradeform input[placeholder="Quantity"]'));
  this.tredeformCancel = element(by.cssContainingText('.tradeform a', 'Cancel'));
  this.tredeformSubmit = element(by.css('.tradeform input[type="submit"]'));

  this.tredeformSubmitClick = function () {
    this.tredeformSubmit.click();
  };

  this.tredeformCancelClick = function () {
    this.tredeformCancel.click();
  };

};

module.exports = new TradePage();