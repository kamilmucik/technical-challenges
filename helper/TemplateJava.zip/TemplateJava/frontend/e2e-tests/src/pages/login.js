var LoginPage = function() {

  this.loginButton = element(by.css('#loginButton'));
  this.inputLogin = element(by.css('#inputLogin'));
  this.inputPassword = element(by.css('#inputPassword'));

  this.get = function() {
    browser.driver.get('http://localhost:9000/#/login');
  };

  this.getTitle = function() {
    return browser.driver.getTitle();
  };

  this.clickLoginButton = function() {
    this.loginButton.click();
  };


};

module.exports = new LoginPage();