var DashboardPage = function () {
  // Definicja buttona 'Order goods'
  this.orderGoodsButton = element(by.css('.sidebar a'));

  this.orderGoodsButtonClick = function () {
    this.orderGoodsButton.click();
  };

};

module.exports = new DashboardPage();