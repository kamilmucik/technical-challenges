# Testy end2end dla Projektu Junior grupa 3


## Przygotowanie do testów
1. Pobierz wymagane narzędzia
  * Zainstaluj przeglądarkę Chrome
  * Zainstaluj [Node.js](https://nodejs.org/)

  * Zainstaluj pozostałe pakiety

    `npm install`
  * Zainstaluj narzędzie protractor 

	`npm install -g protractor`

  * Zaktualizuj drivery

	`webdriver-manager update`

2. Sprawdź poprawność instalacji  
  * Wystartuj przykładowy test poleceniem

    `protractor conf\login.js`
3. Jeśli nie masz swojego ulubionego edytora JavaScript zainstaluj [Atom](https://atom.io/)

**Uwaga:** W przypadku problemów w środowisku Windows zapoznaj się z postem [Nodejs cannot find installed module on Windows](http://stackoverflow.com/questions/9587665/nodejs-cannot-find-installed-module-on-windows/). Jeśli ciągle będziesz miał problem zgłoś go w zakładce `Issues`. Postaram się pomóc.


## Wszystkie testy odpala sie w plikach znajdujących się w conf za pomocą protractora
protractor conf/plik.js

## Pattern protractorowy zakłada, że definiuje się strony jako obiekty i dodaje się do nich funkcje. Taki opis jest w src/pages a testy do nich src/specs z sopiskiem spec
