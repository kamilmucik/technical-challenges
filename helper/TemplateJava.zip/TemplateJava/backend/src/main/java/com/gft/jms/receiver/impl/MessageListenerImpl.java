package com.gft.jms.receiver.impl;

import com.gft.jms.receiver.ReceiverService;
import org.apache.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

/**
 * Created by azws on 2016-07-19.
 */
@Service
public class MessageListenerImpl implements MessageListener {

    private final static org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MessageListenerImpl.class);

    private ReceiverService receiverService;

    @Autowired
    public MessageListenerImpl(ReceiverService receiverService) {
        this.receiverService = receiverService;
    }

    private ObjectMessage receiveMessage(Message message) {
        LOGGER.debug("Casting message received in backend to ObjectMessage object");
        ObjectMessage objectMessage = null;
        if(message instanceof ObjectMessage) {
            objectMessage = (ObjectMessage) message;
        }
        return objectMessage;
    }

    @Override
    public void onMessage(Message message) {
        ObjectMessage receivedMessage = receiveMessage(message);
        try {
            receiverService.handleRequest(receivedMessage);
        } catch (JMSException e) {
            LOGGER.error("Error receiving message in backend", e);
        }
    }
}
