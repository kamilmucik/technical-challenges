package com.gft.dao;

import com.gft.model.Product;
import com.gft.model.Quotation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by azws on 2016-08-29.
 */
public interface QuotationDao extends CrudRepository<Quotation, Long> {

    Page<Quotation> findAll(Pageable pageable);

    Quotation findByProduct_Id(Long productId);

    Quotation findByProduct_IdAndDateBetweenOrderByDateAsc(Long productId, Date date1, Date date2);

    Iterable<Quotation> findByDateBefore(Date date);

    @Modifying
    @Transactional
    @Query("update Quotation q set q.exchangeChange = :exchangeChange, q.date = :date where q.product.id = :productId")
    void updateQuotation(@Param("productId") Long productId, @Param("exchangeChange") BigDecimal exchangeChange, @Param("date") Date date);
}
