package com.gft.dao;

import com.gft.model.Asset;
import com.gft.model.Order;
import com.gft.model.Owner;
import javafx.util.Pair;
import org.apache.commons.lang3.mutable.MutableInt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Created by azws on 2016-08-09.
 */

public class OrderProcessor {

    final static Logger LOGGER = LoggerFactory.getLogger(OrderProcessor.class);

    private volatile BigDecimal soldAssetsPurchaseValue = BigDecimal.ZERO;

    public BigDecimal getSoldAssetsPurchaseValue() {
        return soldAssetsPurchaseValue;
    }

    public boolean userOwnsEnoughAssets(List<Asset> assetsList, Integer orderVolume) {
        LOGGER.debug("Checking if owner with id {} has assets for sale", assetsList.get(0).getOwner().getId());
        Integer assetsVolume = assetsList.parallelStream().mapToInt(a -> a.getVolume()).sum();
        return assetsVolume >= orderVolume ? true : false;
    }

    public void fillOrderWithRequiredData(Long ownerId, Order order) {
        order.setTransactionPrice(order.getPrice().multiply(BigDecimal.valueOf(order.getVolume())));
        order.setOwner(new Owner().setId(ownerId));
        order.setOrderDate(new Date());
    }

    private Pair<Integer, Integer> calculateAssetsForSale(List<Asset> assetsList, Integer orderVolume) {
        LOGGER.debug("Calculating assets owned by owner with id {}", assetsList.get(0).getOwner().getId());
        MutableInt orderVolumeMutable = new MutableInt(orderVolume);
        AtomicInteger assetIndex = new AtomicInteger();

        MutableInt collect = assetsList.stream().collect(MutableInt::new, (MutableInt sum, Asset a) -> {
            if (sum.compareTo(orderVolumeMutable) == -1) {
                sum.add(a.getVolume());
                assetIndex.incrementAndGet();
            } else {
                return;
            }
        }, MutableInt::add);
        return new Pair<>(collect.getValue(), assetIndex.get());
    }

    public Pair<List<Asset>, Asset> getModifiedAssets(List<Asset> assetsList, Integer orderVolume) {

        Pair<Integer, Integer> volumeAndAssetIndex = calculateAssetsForSale(assetsList, orderVolume);
        Integer resultVolume = volumeAndAssetIndex.getKey();
        Integer lastModifiedAssetIndex = volumeAndAssetIndex.getValue();

        List<Asset> modifiedAssets = assetsList.parallelStream().limit(lastModifiedAssetIndex).collect(Collectors.toList());
        Asset assetToUpdate = null;

        LOGGER.debug("Dispatching assets owned by owner with id: {} between assets for remove and update", assetsList.get(0).getOwner().getId());
        if (orderVolume.compareTo(resultVolume) == 0) {

            modifiedAssets.parallelStream().forEach(a -> soldAssetsPurchaseValue = soldAssetsPurchaseValue.add(a.getPurchasePrice()));
        } else if (orderVolume.compareTo(resultVolume) == -1) {

            assetToUpdate = modifiedAssets.remove(modifiedAssets.size() - 1);
            modifiedAssets.parallelStream().forEach(a -> soldAssetsPurchaseValue = soldAssetsPurchaseValue.add(a.getPurchasePrice()));
            Integer newVolume = resultVolume - orderVolume;
            Integer soldVolume = assetToUpdate.getVolume() - newVolume;
            soldAssetsPurchaseValue = soldAssetsPurchaseValue.add(assetToUpdate.getPrice().multiply(BigDecimal.valueOf(soldVolume)));
            assetToUpdate.setVolume(newVolume);
        }
        return new Pair<>(modifiedAssets, assetToUpdate);
    }

}
