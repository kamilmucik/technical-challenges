package com.gft.dao;

import com.gft.model.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by azws on 2016-07-13.
 */

@Repository
public interface OrderDao extends CrudRepository<Order, Long> {

    Page<Order> findByOwner_Id(Long ownerId, Pageable pageable);

}
