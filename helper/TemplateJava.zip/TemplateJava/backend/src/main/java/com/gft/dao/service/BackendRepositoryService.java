package com.gft.dao.service;

import com.gft.dto.OrderDto;
import com.gft.dto.UserDto;
import com.gft.message.*;
import org.springframework.data.domain.Pageable;

/**
 * Created by azws on 2016-07-18.
 */
public interface BackendRepositoryService {

    ActiveOrdersResponse getActiveOrders(Long userId, Pageable pageable);

    AvailableProductsResponse getAvailableProducts(Pageable pageable);

    NewOrderResponse saveNewOrder(Long userId, OrderDto orderDto);

    UserDto getOwner(Long userId);

    OwnedAssetsResponse getOwnedAssets(Long userI, Pageable pageable);

    StockQuotesResponse getStockQuotes(Pageable pageable);
}
