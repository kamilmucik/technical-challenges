package com.gft.jms.sender;

import com.gft.dto.OrderDto;
import org.springframework.data.domain.Pageable;

/**
 * Created by azws on 2016-08-18.
 */
public interface MessagingService {

    void sendGetUserResponse(Long userId, String correlationId);

    void sendActiveOrdersResponse(Long userId, Pageable pageable, String correlationId);

    void sendAvailableProductsResponse(Pageable pageable, String correlationId);

    void sendCreateNewOrderResponse(Long userId, OrderDto orderDto, String correlationId);

    void sendOwnedAssetsResponse(Long userId, Pageable pageable, String correlationId);

    void sendStockQuotesResponse(Pageable pageable, String correlationId);
}
