package com.gft.dao;

import com.gft.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by azws on 2016-07-28.
 */
public interface ProductDao extends CrudRepository<Product, Long> {

    Page<Product> findAll(Pageable pageable);

    @Modifying
    @Transactional
    @Query("update Product p set p.price = :price where p.id = :productId")
    void updateProductPrice(@Param("productId") Long productId, @Param("price") BigDecimal price);

}
