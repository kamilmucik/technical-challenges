package com.gft.dao;

import com.gft.model.Order;
import com.gft.model.Quotation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by azws on 2016-08-29.
 */
public class QuotationProcessor {

    final static Logger LOGGER = LoggerFactory.getLogger(QuotationProcessor.class);

    public static Quotation processQuotation(Order saleOrder, Quotation quotation) {
        if (orderProductPriceIsLowerThanCurrentPrice(saleOrder.getPrice(), quotation.getProduct().getPrice())) {
            BigDecimal exchangeChange = calculateExchangeChange(saleOrder.getPrice(), quotation.getProduct().getPrice());
            quotation.setExchangeChange(exchangeChange);
            return quotation;
        }
        return null;
    }

    private static boolean orderProductPriceIsLowerThanCurrentPrice(BigDecimal orderPrice, BigDecimal currentPrice) {
        if (orderPrice.compareTo(currentPrice) == -1) {
            return true;
        }
        return false;
    }

    private static BigDecimal calculateExchangeChange(BigDecimal newProductPrice, BigDecimal oldProductPrice) {
        return newProductPrice.subtract(oldProductPrice).divide(newProductPrice, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
    }

    public static Date getDateHourAgo() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, -1);
        return calendar.getTime();
    }
}
