package com.gft.dao;

import com.gft.model.Asset;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by azws on 2016-08-08.
 */
public interface AssetDao extends CrudRepository<Asset, Long> {

    Page<Asset> findByOwner_Id(Long ownerId, Pageable pageable);

    List<Asset> findByOwner_IdAndProduct_IdOrderByPurchaseDateDesc(Long ownerId, Long productId);

    @Modifying
    @Transactional
    @Query("update Asset a set a.volume = :volume, a.purchasePrice = :purchasePrice where a.id = :assetId")
    void updateVolumeAndPurchaseValue(@Param("assetId") Long assetId, @Param("volume") Integer volume, @Param("purchasePrice") BigDecimal purchasePrice);
}
