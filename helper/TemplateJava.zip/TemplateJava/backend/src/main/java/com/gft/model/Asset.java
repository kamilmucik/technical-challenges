package com.gft.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by azws on 2016-08-03.
 */

@Entity
@Table(name = "\"asset\"")
public class Asset {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "asset_id", nullable = false, unique = true)
    private Long id;

    @Column(nullable = false)
    private Integer volume;

    @Column(nullable = false)
    private BigDecimal price;

    @Column(nullable = false)
    private BigDecimal purchasePrice;

    @Column(nullable = false)
    private BigDecimal profit;

    @Column(nullable = false)
    private Date purchaseDate;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private Owner owner;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    public Asset() {
    }

    public Asset(Long id, Integer volume, BigDecimal price, BigDecimal purchasePrice, BigDecimal profit, Date purchaseDate, Owner owner, Product product) {
        this.id = id;
        this.volume = volume;
        this.price = price;
        this.purchasePrice = purchasePrice;
        this.profit = profit;
        this.purchaseDate = purchaseDate;
        this.owner = owner;
        this.product = product;
    }

    public Asset(Integer volume, BigDecimal price) {
        this.volume = volume;
        this.price = price;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @Override
    public String toString() {
        return "Asset{" +
                "id=" + id +
                ", volume=" + volume +
                ", price=" + price +
                ", purchasePrice=" + purchasePrice +
                ", profit=" + profit +
                ", purchaseDate=" + purchaseDate +
                ", owner=" + owner +
                ", product=" + product +
                '}';
    }
}
