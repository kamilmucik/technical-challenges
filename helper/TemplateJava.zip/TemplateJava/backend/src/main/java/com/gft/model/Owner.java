package com.gft.model;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * Created by azws on 2016-07-13.
 */

@Entity
@Table(name = "\"owner\"")
public class Owner implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "owner_id", unique = true, nullable = false)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private BigDecimal availableFunds;

    @Column(nullable = false)
    private BigDecimal portfolioValue;

    @Column(nullable = false)
    private BigDecimal rateOfReturn;

    @OneToMany
    @JoinTable(name = "owner_order", joinColumns = @JoinColumn(name = "owner_id", referencedColumnName = "owner_id"), inverseJoinColumns = @JoinColumn(name = "order_id", referencedColumnName = "order_id"))
    private List<Order> ordersList;

    @OneToMany
    @JoinTable(name = "owner_asset", joinColumns = @JoinColumn(name = "owner_id", referencedColumnName = "owner_id"), inverseJoinColumns = @JoinColumn(name = "asset_id", referencedColumnName = "asset_id"))
    private List<Asset> assetsList;

    public Owner() {
    }

    public Owner(Long id, Long userId, BigDecimal availableFunds, BigDecimal portfolioValue, BigDecimal rateOfReturn, List<Order> ordersList, List<Asset> assetsList) {
        this.id = id;
        this.userId = userId;
        this.availableFunds = availableFunds;
        this.portfolioValue = portfolioValue;
        this.rateOfReturn = rateOfReturn;
        this.ordersList = ordersList;
        this.assetsList = assetsList;
    }

    public Long getId() {
        return id;
    }

    public Owner setId(Long id) {
        this.id = id;
        return this;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public BigDecimal getAvailableFunds() {
        return availableFunds;
    }

    public void setAvailableFunds(BigDecimal availableFunds) {
        this.availableFunds = availableFunds;
    }

    public BigDecimal getPortfolioValue() {
        return portfolioValue;
    }

    public void setPortfolioValue(BigDecimal portfolioValue) {
        this.portfolioValue = portfolioValue;
    }

    public BigDecimal getRateOfReturn() {
        return rateOfReturn;
    }

    public void setRateOfReturn(BigDecimal rateOfReturn) {
        this.rateOfReturn = rateOfReturn;
    }

    public List<Order> getOrdersList() {
        return ordersList;
    }

    public void setOrdersList(List<Order> ordersList) {
        this.ordersList = ordersList;
    }

    public List<Asset> getAssetsList() {
        return assetsList;
    }

    public void setAssetsList(List<Asset> assetsList) {
        this.assetsList = assetsList;
    }

    @Override
    public String toString() {
        return "Owner{" +
                "id=" + id +
                ", userId=" + userId +
                ", availableFunds=" + availableFunds +
                ", portfolioValue=" + portfolioValue +
                ", rateOfReturn=" + rateOfReturn +
                ", ordersList=" + ordersList +
                ", assetsList=" + assetsList +
                '}';
    }
}
