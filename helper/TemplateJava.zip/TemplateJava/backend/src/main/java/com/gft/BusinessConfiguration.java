package com.gft;

import com.gft.dto.*;
import com.gft.model.*;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;

/**
 * Created by azws on 2016-07-28.
 */
@Configuration
public class BusinessConfiguration {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessConfiguration.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("classpath:add_new_owner.txt")
    private Resource newUserScriptResource;

    @Value("classpath:add_products.txt")
    private Resource addProductsScriptResource;

    @Value("classpath:add_assets.txt")
    private Resource addAssetsScriptResource;

    @Value("classpath:add_quotations.txt")
    private Resource addQuotationsScriptResource;

    @PostConstruct
    public void runSqlScripts() throws Exception {
        executeDBScripts(newUserScriptResource.getInputStream());
        executeDBScripts(addProductsScriptResource.getInputStream());
        executeDBScripts(addAssetsScriptResource.getInputStream());
        executeDBScripts(addQuotationsScriptResource.getInputStream());
    }

    private void executeDBScripts(InputStream inputStream) throws IOException, SQLException {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            String str;
            StringBuffer sb = new StringBuffer();
            while ((str = in.readLine()) != null) {
                sb.append(str + "\n ");
            }
            in.close();
            jdbcTemplate.execute(sb.toString());
        } catch (Exception e) {
            LOGGER.error("Error executing sql script", e);
        }
    }

    @Bean
    public static MapperFacade mapperFacade() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(Order.class, OrderDto.class)
                .field("product.name", "productName")
                .field("product.id", "productId")
                .byDefault()
                .register();

        mapperFactory.classMap(Asset.class, AssetDto.class)
                .field("product", "productDto")
                .byDefault()
                .register();

        mapperFactory.classMap(Product.class, ProductDto.class)
                .byDefault()
                .register();

        mapperFactory.classMap(Owner.class, UserDto.class)
                .byDefault()
                .register();

        mapperFactory.classMap(Quotation.class, QuotationDto.class)
                .field("product.name", "productName")
                .field("product.price", "exchange")
                .byDefault()
                .register();

        return mapperFactory.getMapperFacade();
    }

}
