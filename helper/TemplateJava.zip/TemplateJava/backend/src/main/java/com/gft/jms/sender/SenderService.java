package com.gft.jms.sender;

import com.gft.dto.OrderDto;
import com.gft.dto.UserDto;
import org.springframework.data.domain.Pageable;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import java.io.Serializable;

/**
 * Created by azws on 2016-07-13.
 */
public interface SenderService {

    <T extends Serializable> void sendResponse(T objectResponse, String correlationId);

}
