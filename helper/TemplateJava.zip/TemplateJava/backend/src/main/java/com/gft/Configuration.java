package com.gft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Created by azws on 2016-07-13.
 */
@SpringBootApplication(scanBasePackages = "com.gft")
@EnableJpaRepositories(basePackages = "com.gft")
@ImportResource("/beans.xml")
@Import(BusinessConfiguration.class)
public class Configuration {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Configuration.class, args);
    }

}