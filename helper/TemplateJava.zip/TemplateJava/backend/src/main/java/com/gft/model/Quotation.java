package com.gft.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by azws on 2016-08-03.
 */

@Entity
@Table(name = "\"quotation\"")
public class Quotation {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "quotation_id", nullable = false)
    private Long id;

    @OneToOne
    @JoinColumn(name = "product_id")
    private Product product;

    @Column(nullable = false)
    private BigDecimal exchangeChange;

    @Column(nullable = false)
    private Date date;

    public Quotation() {
    }

    public Quotation(Long id, Product product, BigDecimal exchangeChange, Date date) {
        this.id = id;
        this.product = product;
        this.exchangeChange = exchangeChange;
        this.date = date;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public BigDecimal getExchangeChange() {
        return exchangeChange;
    }

    public void setExchangeChange(BigDecimal exchangeChange) {
        this.exchangeChange = exchangeChange;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Quotation{" +
                "id=" + id +
                ", product=" + product +
                ", exchangeChange=" + exchangeChange +
                ", date=" + date +
                '}';
    }
}
