package com.gft.jms.sender.impl;

import com.gft.dao.service.BackendRepositoryService;
import com.gft.dto.OrderDto;
import com.gft.jms.sender.SenderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.Session;
import java.io.Serializable;

/**
 * Created by azws on 2016-07-18.
 */

@Service
public class SenderServiceImpl implements SenderService {

    private final static Logger LOGGER = LoggerFactory.getLogger(SenderServiceImpl.class);

    @Autowired
    private String backToMiddleQueue;

    private JmsTemplate jmsTemplate;

    @Autowired
    public SenderServiceImpl(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    private <T extends Serializable> MessageCreator createObjectMessage(T message, String correlationId) {
        return (Session session) -> {
            Message messageToSend = session.createObjectMessage(message);
            messageToSend.setJMSCorrelationID(correlationId);
            return messageToSend;
        };
    }

    public <T extends Serializable> void sendResponse(T objectResponse, String correlationId) {
        LOGGER.debug("Sending message response to middle tier with correlation ID: {}", correlationId);
        jmsTemplate.send(backToMiddleQueue, createObjectMessage(objectResponse, correlationId));
    }


}
