package com.gft.jms.receiver.impl;

import com.gft.JmsType;
import com.gft.dao.service.BackendRepositoryService;
import com.gft.jms.receiver.ReceiverService;
import com.gft.jms.sender.MessagingService;
import com.gft.jms.sender.SenderService;
import com.gft.message.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;

/**
 * Created by azws on 2016-08-06.
 */
@Service
public class ReceiverServiceImpl implements ReceiverService {

    private final static Logger LOGGER = LoggerFactory.getLogger(ReceiverServiceImpl.class);

    private MessagingService messagingService;
    private BackendRepositoryService backendRepositoryService;

    @Autowired
    public ReceiverServiceImpl(MessagingService messagingService, BackendRepositoryService backendRepositoryService) {
        this.messagingService = messagingService;
        this.backendRepositoryService = backendRepositoryService;
    }

    public void handleRequest(ObjectMessage objectMessage) throws JMSException {
        LOGGER.debug("Handling message in backend with correlation ID: {}", objectMessage.getJMSCorrelationID());
        JmsType messageType = JmsType.valueOf(objectMessage.getJMSType());
        String correlationId = objectMessage.getJMSCorrelationID();
        switch(messageType) {
            case GET_PRODUCTS_LIST:
                AvailableProductsRequest availableProductsRequest = (AvailableProductsRequest) objectMessage.getObject();
                messagingService.sendAvailableProductsResponse(availableProductsRequest.getPageable(), correlationId);
                break;
            case CREATE_NEW_ORDER:
                NewOrderRequest newOrderRequest = (NewOrderRequest) objectMessage.getObject();
                messagingService.sendCreateNewOrderResponse(newOrderRequest.getUserId(), newOrderRequest.getOrderDto(), correlationId);
                break;
            case GET_ACTIVE_ORDERS:
                ActiveOrdersRequest activeOrdersRequest = (ActiveOrdersRequest) objectMessage.getObject();
                messagingService.sendActiveOrdersResponse(activeOrdersRequest.getUserId(), activeOrdersRequest.getPageable(), correlationId);
                break;
            case GET_USER:
                messagingService.sendGetUserResponse((Long) objectMessage.getObject(), correlationId);
                break;
            case GET_OWNED_ASSETS:
                OwnedAssetsRequest ownedAssetsRequest = (OwnedAssetsRequest) objectMessage.getObject();
                messagingService.sendOwnedAssetsResponse(ownedAssetsRequest.getUserId(), ownedAssetsRequest.getPageable(), correlationId);
                break;
            case GET_STOCK_QUOTES:
                StockQuotesRequest stockQuotesRequest = (StockQuotesRequest) objectMessage.getObject();
                messagingService.sendStockQuotesResponse(stockQuotesRequest.getPageable(), correlationId);
        }
    }
}
