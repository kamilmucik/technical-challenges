package com.gft.dao.service.impl;

import com.gft.dao.*;
import com.gft.dao.service.BackendRepositoryService;
import com.gft.dto.*;
import com.gft.message.*;
import com.gft.model.*;
import javafx.util.Pair;
import ma.glasnost.orika.MapperFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by azws on 2016-07-18.
 */

@Service
public class BackendRepositoryServiceImpl implements BackendRepositoryService {

    private final static Logger LOGGER = LoggerFactory.getLogger(BackendRepositoryServiceImpl.class);

    private OrderDao orderDao;

    private OwnerDao ownerDao;

    private ProductDao productDao;

    private AssetDao assetDao;

    private QuotationDao quotationDao;

    private MapperFacade mapperFacade;

    private OrderProcessor orderProcessor;

    @Autowired
    public BackendRepositoryServiceImpl(OrderDao orderDao, OwnerDao ownerDao, ProductDao productDao, AssetDao assetDao, MapperFacade mapperFacade, QuotationDao quotationDao) {
        this.orderDao = orderDao;
        this.ownerDao = ownerDao;
        this.productDao = productDao;
        this.assetDao = assetDao;
        this.mapperFacade = mapperFacade;
        this.quotationDao = quotationDao;
    }

    @Override
    public UserDto getOwner(Long userId) {
        LOGGER.debug("Getting owner with user id: {} from database", userId);
        Owner foundOwner = ownerDao.findByUserId(userId);
        UserDto mappedUser = null;
        if (foundOwner != null) {
            mappedUser = mapperFacade.map(foundOwner, UserDto.class);
        }
        return mappedUser;
    }

    @Override
    public ActiveOrdersResponse getActiveOrders(Long userId, Pageable pageable) {
        Long ownerId = ownerDao.findByUserId(userId).getId();
        LOGGER.debug("Getting active orders from database for owner with id: {}", ownerId);
        Page<Order> activeOrdersList = orderDao.findByOwner_Id(ownerId, pageable);
        Page<OrderDto> activeOrdersDtoList = new PageImpl<>(mapperFacade.mapAsList(activeOrdersList, OrderDto.class), pageable, activeOrdersList.getTotalElements());
        return new ActiveOrdersResponse(activeOrdersDtoList);
    }

    @Override
    public AvailableProductsResponse getAvailableProducts(Pageable pageable) {
        LOGGER.debug("Getting available products from database");
        Page<Product> availableProductsList = productDao.findAll(pageable);
        Page<ProductDto> availableProductsDtoList = new PageImpl<>(mapperFacade.mapAsList(availableProductsList, ProductDto.class), pageable, availableProductsList.getTotalElements());
        return new AvailableProductsResponse(availableProductsDtoList);
    }

    private OrderStatus savePurchaseOrder(Order order) {
        OrderStatus orderStatus = OrderStatus.INSUFFICIENT_FUNDS;
        BigDecimal orderValue = order.getTransactionPrice();
        Owner owner = ownerDao.findOwnerWithSufficientFunds(order.getOwner().getId(), orderValue);
        if (owner != null) {
            orderDao.save(order);
            orderStatus = OrderStatus.OK;
        }
        return orderStatus;
    }

    private OrderStatus saveSaleOrder(Order order) {
        OrderStatus orderStatus = OrderStatus.NOT_ENOUGH_AMOUNT_OF_PRODUCT;
        List<Asset> assetsList = assetDao.findByOwner_IdAndProduct_IdOrderByPurchaseDateDesc(order.getOwner().getId(), order.getProduct().getId());
        if (assetsList != null && !assetsList.isEmpty() && orderProcessor.userOwnsEnoughAssets(assetsList, order.getVolume())) {
            Pair<List<Asset>, Asset> modifiedAssets = orderProcessor.getModifiedAssets(assetsList, order.getVolume());
            List<Asset> assetsForRemove = modifiedAssets.getKey();
            Asset assetForUpdate = modifiedAssets.getValue();

            LOGGER.debug("Saving sale order with id: {} in database", order.getId());
            orderDao.save(order);

            assetsForRemove.parallelStream().forEach(a -> {
                LOGGER.debug("Removing asset with id: {} from database", a.getId());
                assetDao.delete(a);
            });

            if (assetForUpdate != null)
                assetDao.updateVolumeAndPurchaseValue(assetForUpdate.getId(), assetForUpdate.getVolume(), assetForUpdate.getPrice().multiply(BigDecimal.valueOf(assetForUpdate.getVolume())));
            LOGGER.debug("Updating volume and purchase value in database for user with id: {}", order.getOwner().getId());

            BigDecimal portfolioValue = ownerDao.findOne(order.getOwner().getId()).getPortfolioValue();
            ownerDao.updateOwnerPortfolioValues(order.getOwner().getId(), portfolioValue.subtract(orderProcessor.getSoldAssetsPurchaseValue()));
            orderStatus = OrderStatus.OK;

            Quotation quotation = quotationDao.findByProduct_Id(order.getProduct().getId());
            quotation = QuotationProcessor.processQuotation(order, quotation);
            if (quotation != null) {
                LOGGER.debug("Updating quotation for product with name: {}", order.getProduct().getName());
                quotationDao.updateQuotation(order.getProduct().getId(), quotation.getExchangeChange(), new Date());
                LOGGER.debug("Updating price of product with name: {}", order.getProduct().getName());
                productDao.updateProductPrice(order.getProduct().getId(), order.getPrice());
            }
        }
        return orderStatus;
    }

    @Override
    public NewOrderResponse saveNewOrder(Long userId, OrderDto orderDto) {
        OrderStatus orderStatus = OrderStatus.UNEXPECTED_ERROR;
        OrderType orderType = orderDto.getOrderType();
        Long ownerId = ownerDao.findByUserId(userId).getId();
        Order order = mapperFacade.map(orderDto, Order.class);
        orderProcessor = new OrderProcessor();
        orderProcessor.fillOrderWithRequiredData(ownerId, order);

        if (orderType.equals(OrderType.SALE)) {
            orderStatus = saveSaleOrder(order);
        } else if (orderType.equals(OrderType.PURCHASE)) {
            orderStatus = savePurchaseOrder(order);
        }
        return new NewOrderResponse(orderStatus);
    }

    @Override
    public OwnedAssetsResponse getOwnedAssets(Long userId, Pageable pageable) {
        Long ownerId = ownerDao.findByUserId(userId).getId();
        LOGGER.debug("Getting assets for owner with id: {} from database", ownerId);
        Page<Asset> ownedAssetsList = assetDao.findByOwner_Id(ownerId, pageable);
        Page<AssetDto> ownedAssetsDtoList = new PageImpl<>(mapperFacade.mapAsList(ownedAssetsList, AssetDto.class), pageable, ownedAssetsList.getTotalElements());
        return new OwnedAssetsResponse(ownedAssetsDtoList);
    }

    @Override
    public StockQuotesResponse getStockQuotes(Pageable pageable) {
        Iterable<Quotation> quotations = quotationDao.findByDateBefore(QuotationProcessor.getDateHourAgo());
        if (quotations != null) {
            quotations.forEach(q -> {
                LOGGER.debug("Updating exchange change value of quotation with product id: {}", q.getProduct().getId());
                quotationDao.updateQuotation(q.getProduct().getId(), BigDecimal.ZERO, new Date());
            });
        }
        LOGGER.debug("Getting stock quotes from database");
        Page<Quotation> stockQuotes = quotationDao.findAll(pageable);
        Page<QuotationDto> stockQuotesDtoList = new PageImpl<>(mapperFacade.mapAsList(stockQuotes, QuotationDto.class), pageable, stockQuotes.getTotalElements());
        return new StockQuotesResponse(stockQuotesDtoList);
    }


}
