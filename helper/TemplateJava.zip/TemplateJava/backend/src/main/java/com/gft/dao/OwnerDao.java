package com.gft.dao;

import com.gft.model.Owner;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * Created by azws on 2016-07-28.
 */

@Repository
public interface OwnerDao extends CrudRepository<Owner, Long> {

    Owner findByUserId(Long userId);

    @Query("select o from Owner o where o.id = :ownerId and o.availableFunds >= :orderValue")
    Owner findOwnerWithSufficientFunds(@Param("ownerId") Long ownerId, @Param("orderValue") BigDecimal orderValue);

    @Modifying
    @Transactional
    @Query("update Owner o set o.availableFunds = :availableFunds where o.id = :ownerId")
    void updateOwnerAvailableFunds(@Param("ownerId") Long ownerId, @Param("availableFunds") BigDecimal availableFunds);

    @Modifying
    @Transactional
    @Query("update Owner o set o.portfolioValue = :portfolioValue where o.id = :ownerId")
    void updateOwnerPortfolioValues(@Param("ownerId") Long ownerId, @Param("portfolioValue") BigDecimal portfolioValue);
}
