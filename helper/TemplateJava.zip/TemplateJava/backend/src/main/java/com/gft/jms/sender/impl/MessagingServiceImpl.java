package com.gft.jms.sender.impl;

import com.gft.dao.service.BackendRepositoryService;
import com.gft.dto.OrderDto;
import com.gft.jms.sender.MessagingService;
import com.gft.jms.sender.SenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 * Created by azws on 2016-08-18.
 */

@Service
public class MessagingServiceImpl implements MessagingService {


    private BackendRepositoryService backendRepositoryService;
    private SenderService senderService;

    @Autowired
    public MessagingServiceImpl(BackendRepositoryService backendRepositoryService, SenderService senderService) {
        this.backendRepositoryService = backendRepositoryService;
        this.senderService = senderService;
    }

    @Override
    public void sendGetUserResponse(Long userId, String correlationId) {
        senderService.sendResponse(backendRepositoryService.getOwner(userId), correlationId);
    }

    @Override
    public void sendActiveOrdersResponse(Long userId, Pageable pageable, String correlationId) {
        senderService.sendResponse(backendRepositoryService.getActiveOrders(userId, pageable), correlationId);
    }

    @Override
    public void sendAvailableProductsResponse(Pageable pageable, String correlationId) {
        senderService.sendResponse(backendRepositoryService.getAvailableProducts(pageable), correlationId);
    }

    @Override
    public void sendCreateNewOrderResponse(Long userId, OrderDto orderDto, String correlationId) {
        senderService.sendResponse(backendRepositoryService.saveNewOrder(userId, orderDto), correlationId);
    }

    @Override
    public void sendOwnedAssetsResponse(Long userId, Pageable pageable, String correlationId) {
        senderService.sendResponse(backendRepositoryService.getOwnedAssets(userId, pageable), correlationId);
    }

    @Override
    public void sendStockQuotesResponse(Pageable pageable, String correlationId) {
        senderService.sendResponse(backendRepositoryService.getStockQuotes(pageable), correlationId);
    }
}
