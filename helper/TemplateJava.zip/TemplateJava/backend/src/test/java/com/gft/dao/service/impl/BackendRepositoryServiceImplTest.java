package com.gft.dao.service.impl;

import com.gft.BusinessConfiguration;
import com.gft.dao.*;
import com.gft.dto.*;
import com.gft.message.ActiveOrdersResponse;
import com.gft.message.AvailableProductsResponse;
import com.gft.message.NewOrderResponse;
import com.gft.message.OwnedAssetsResponse;
import com.gft.model.*;
import javafx.util.Pair;
import ma.glasnost.orika.MapperFacade;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.*;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by azws on 2016-08-01.
 */
public class BackendRepositoryServiceImplTest {

    OwnerDao ownerDaoMock;
    ProductDao productDaoMock;
    OrderDao orderDaoMock;
    AssetDao assetDaoMock;
    MapperFacade mapper;
    QuotationDao quotationDaoMock;
    Pageable pageable;

    @Before
    public void setUp() throws Exception {
        ownerDaoMock = mock(OwnerDao.class);
        productDaoMock = mock(ProductDao.class);
        orderDaoMock = mock(OrderDao.class);
        assetDaoMock = mock(AssetDao.class);
        pageable = mock(Pageable.class);
        quotationDaoMock = mock(QuotationDao.class);
        mapper = BusinessConfiguration.mapperFacade();
    }

    @Test
    public void shouldFindUserInDatabase() {
        Owner owner = new Owner();

        when(ownerDaoMock.findByUserId(anyLong())).thenReturn(owner);
        BackendRepositoryServiceImpl daoService = new BackendRepositoryServiceImpl(orderDaoMock, ownerDaoMock, productDaoMock, assetDaoMock, mapper, quotationDaoMock);
        UserDto resultUser = daoService.getOwner(1L);

        Assert.assertNotNull(resultUser);
    }

    @Test
    public void shouldSavePurchaseOrderInDatabase() {
        Owner owner = new Owner();
        OrderDto orderDto = new OrderDto(){
            {
                setProductId(1L);
                setVolume(100);
                setPrice(BigDecimal.TEN);
                setOrderType(OrderType.PURCHASE);
            }
        };

        when(ownerDaoMock.findByUserId(anyLong())).thenReturn(new Owner());
        when(ownerDaoMock.findOwnerWithSufficientFunds(anyLong(), BigDecimal.valueOf(anyDouble()))).thenReturn(owner);
        BackendRepositoryServiceImpl daoService = new BackendRepositoryServiceImpl(orderDaoMock, ownerDaoMock, productDaoMock, assetDaoMock, mapper, quotationDaoMock);
        NewOrderResponse result = daoService.saveNewOrder(1L, orderDto);

        Assert.assertEquals(OrderStatus.OK, result.getOrderStatus());
    }

    @Test
    public void shouldSaveSaleOrderInDatabase() {
        Owner owner = new Owner(){
            {
                setPortfolioValue(BigDecimal.ONE);
                setId(1L);
            }
        };
        List<Asset> assetsList = new ArrayList<Asset>() {
            {
                add(new Asset() {
                    {
                        this.setVolume(10);
                        this.setOwner(owner);
                        this.setPrice(BigDecimal.ONE);
                    }
                });
            }
        };
        OrderDto orderDto = new OrderDto(){
            {
                setProductId(1L);
                setVolume(1);
                setPrice(BigDecimal.TEN);
                setOrderType(OrderType.SALE);
            }
        };
        Product product = new Product(1L, "gold", BigDecimal.TEN);

        when(ownerDaoMock.findByUserId(anyLong())).thenReturn(new Owner());
        when(assetDaoMock.findByOwner_IdAndProduct_IdOrderByPurchaseDateDesc(anyLong(), anyLong())).thenReturn(assetsList);
        when(ownerDaoMock.findOne(anyLong())).thenReturn(owner);
        when(quotationDaoMock.findByProduct_Id(anyLong())).thenReturn(new Quotation(1L, product, BigDecimal.ONE, new Date()));
        BackendRepositoryServiceImpl daoService = new BackendRepositoryServiceImpl(orderDaoMock, ownerDaoMock, productDaoMock, assetDaoMock, mapper, quotationDaoMock);
        NewOrderResponse result = daoService.saveNewOrder(1L, orderDto);

        Assert.assertEquals(OrderStatus.OK, result.getOrderStatus());
    }

    @Test
    public void shouldReturnActiveOrders() {
        PageRequest pageRequest = new PageRequest(0, 10);
        Page<Order> activeOrdersList = new PageImpl<>(new ArrayList<>(), pageRequest, anyInt());
        when(orderDaoMock.findByOwner_Id(anyLong(), pageRequest)).thenReturn(activeOrdersList);
        when(ownerDaoMock.findByUserId(anyLong())).thenReturn(new Owner());

        BackendRepositoryServiceImpl daoService = new BackendRepositoryServiceImpl(orderDaoMock, ownerDaoMock, productDaoMock, assetDaoMock, mapper, quotationDaoMock);
        ActiveOrdersResponse activeOrdersResponse = daoService.getActiveOrders(1L, pageRequest);

        Assert.assertNotNull(activeOrdersResponse.getActiveOrders());
    }

    @Test
    public void shouldReturnProductsList() {
        PageRequest pageRequest = new PageRequest(0, 10);
        Page<Product> availableProductsList = new PageImpl<>(new ArrayList<>(), pageRequest, anyInt());
        when(productDaoMock.findAll(pageRequest)).thenReturn(availableProductsList);

        BackendRepositoryServiceImpl daoService = new BackendRepositoryServiceImpl(orderDaoMock, ownerDaoMock, productDaoMock, assetDaoMock, mapper, quotationDaoMock);
        AvailableProductsResponse availableProductsResponse = daoService.getAvailableProducts(pageRequest);

        Assert.assertNotNull(availableProductsResponse.getAvailableProducts());
    }

    @Test
    public void shouldReturnOwnedAssetsList() {
        PageRequest pageRequest = new PageRequest(0, 10);
        Page<Asset> assetsList = new PageImpl<>(new ArrayList<>(), pageRequest, anyInt());
        when(assetDaoMock.findByOwner_Id(anyLong(), pageRequest)).thenReturn(assetsList);
        when(ownerDaoMock.findByUserId(anyLong())).thenReturn(new Owner());

        BackendRepositoryServiceImpl daoService = new BackendRepositoryServiceImpl(orderDaoMock, ownerDaoMock, productDaoMock, assetDaoMock, mapper, quotationDaoMock);
        OwnedAssetsResponse ownedAssetsResponse = daoService.getOwnedAssets(1L, pageRequest);

        Assert.assertNotNull(ownedAssetsResponse.getOwnedAssets());
    }

    @Test
    public void shouldReturnNotNull() {
        Assert.assertNotNull(1);
    }

}