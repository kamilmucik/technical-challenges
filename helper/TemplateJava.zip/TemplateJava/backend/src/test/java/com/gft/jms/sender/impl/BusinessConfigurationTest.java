package com.gft.jms.sender.impl;

import com.gft.BusinessConfiguration;
import com.gft.dto.OrderDto;
import com.gft.dto.OrderType;
import com.gft.model.Order;
import ma.glasnost.orika.MapperFacade;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;

/**
 * Created by azws on 2016-07-28.
 */
public class BusinessConfigurationTest {

    MapperFacade mapper = BusinessConfiguration.mapperFacade();

    OrderDto objectToMap;

    @Before
    public void setUp() throws Exception {
        objectToMap = new OrderDto();
        objectToMap.setProductId(1L);
        objectToMap.setProductName("Gold");
        objectToMap.setVolume(10);
        objectToMap.setOrderType(OrderType.SALE);
        objectToMap.setTransactionPrice(new BigDecimal(1000.00));
        objectToMap.setPrice(new BigDecimal(100.00));
    }

    @Test
    public void shouldMapPlainObject() throws Exception {
        Order target = mapper.map(objectToMap, Order.class);

        Assert.assertEquals(objectToMap.getProductId(), target.getProduct().getId());
        Assert.assertEquals(objectToMap.getProductName(), target.getProduct().getName());
        Assert.assertEquals(objectToMap.getVolume(), target.getVolume());
        Assert.assertEquals(objectToMap.getOrderType(), target.getOrderType());
        Assert.assertEquals(objectToMap.getTransactionPrice(), target.getTransactionPrice());
        Assert.assertEquals(objectToMap.getPrice(), target.getPrice());
    }

    @Test
    public void shouldMapList() throws Exception {
        List<OrderDto> listToMap = new ArrayList<>();
        listToMap.add(objectToMap);

        List<Order> targetList = mapper.mapAsList(listToMap, Order.class);

        Assert.assertEquals(listToMap.get(0).getProductId(), targetList.get(0).getProduct().getId());
        Assert.assertEquals(listToMap.get(0).getProductName(), targetList.get(0).getProduct().getName());
        Assert.assertEquals(listToMap.get(0).getVolume(), targetList.get(0).getVolume());
        Assert.assertEquals(listToMap.get(0).getOrderType(), targetList.get(0).getOrderType());
        Assert.assertEquals(listToMap.get(0).getTransactionPrice(), targetList.get(0).getTransactionPrice());
        Assert.assertEquals(listToMap.get(0).getPrice(), targetList.get(0).getPrice());
    }
}