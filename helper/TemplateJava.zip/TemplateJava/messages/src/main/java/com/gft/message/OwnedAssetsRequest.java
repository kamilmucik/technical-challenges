package com.gft.message;

import org.springframework.data.domain.Pageable;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-10.
 */
public class OwnedAssetsRequest implements Serializable {

    private Long userId;
    private Pageable pageable;


    public OwnedAssetsRequest(Long userId, Pageable pageable) {
        this.userId = userId;
        this.pageable = pageable;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Pageable getPageable() {
        return pageable;
    }

    public void setPageable(Pageable pageable) {
        this.pageable = pageable;
    }

}
