package com.gft.dto;

/**
 * Created by azws on 2016-08-08.
 */
public enum OrderStatus {

    OK, INSUFFICIENT_FUNDS, NOT_ENOUGH_AMOUNT_OF_PRODUCT, UNEXPECTED_ERROR

}
