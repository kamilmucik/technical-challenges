package com.gft.message;

import com.gft.dto.ProductDto;
import org.springframework.data.domain.Page;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-06.
 */
public class AvailableProductsResponse implements Serializable {

    private Page<ProductDto> availableProducts;

    public AvailableProductsResponse(Page<ProductDto> availableProducts) {
        this.availableProducts = availableProducts;
    }

    public Page<ProductDto> getAvailableProducts() {
        return availableProducts;
    }

    public void setAvailableProducts(Page<ProductDto> availableProducts) {
        this.availableProducts = availableProducts;
    }
}
