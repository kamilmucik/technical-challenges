package com.gft.dto;

/**
 * Created by azws on 2016-08-06.
 */
public enum OrderType {

    PURCHASE, SALE

}
