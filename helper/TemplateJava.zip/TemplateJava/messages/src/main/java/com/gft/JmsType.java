package com.gft;

/**
 * Created by azws on 2016-07-20.
 */
public enum JmsType {

    GET_PRODUCTS_LIST, CREATE_NEW_ORDER, GET_ACTIVE_ORDERS, GET_USER, GET_OWNED_ASSETS, GET_STOCK_QUOTES

}
