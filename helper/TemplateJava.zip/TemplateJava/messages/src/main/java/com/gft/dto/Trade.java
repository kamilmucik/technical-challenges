package com.gft.dto;

import java.util.List;

/**
 * Created by azws on 2016-07-18.
 */
public class Trade {

    private OrderDto orderDto;
    private List<ProductDto> productsList;

}
