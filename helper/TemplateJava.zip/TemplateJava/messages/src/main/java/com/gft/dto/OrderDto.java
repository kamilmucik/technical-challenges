package com.gft.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by azws on 2016-07-13.
 */


public class OrderDto implements Serializable {

    private Long productId;

    private String productName;

    private Integer volume;

    private OrderType orderType;

    private BigDecimal price;

    private BigDecimal transactionPrice;

    private Date orderDate;

    public OrderDto() {};

    public OrderDto(Long productId, String productName, Integer volume, OrderType orderType, BigDecimal price, BigDecimal transactionPrice, Date orderDate) {
        this.productId = productId;
        this.productName = productName;
        this.volume = volume;
        this.orderType = orderType;
        this.price = price;
        this.transactionPrice = transactionPrice;
        this.orderDate = orderDate;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getTransactionPrice() {
        return transactionPrice;
    }

    public void setTransactionPrice(BigDecimal transactionPrice) {
        this.transactionPrice = transactionPrice;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    @Override
    public String toString() {
        return "OrderDto{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", volume=" + volume +
                ", orderType=" + orderType +
                ", price=" + price +
                ", transactionPrice=" + transactionPrice +
                ", orderDate=" + orderDate +
                '}';
    }
}