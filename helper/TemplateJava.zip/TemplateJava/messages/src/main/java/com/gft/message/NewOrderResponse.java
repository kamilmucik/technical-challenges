package com.gft.message;

import com.gft.dto.OrderDto;
import com.gft.dto.OrderStatus;
import com.gft.dto.ProductDto;
import org.springframework.data.domain.Page;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-08.
 */
public class NewOrderResponse implements Serializable {

    private OrderStatus orderStatus;

    public NewOrderResponse(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }
}
