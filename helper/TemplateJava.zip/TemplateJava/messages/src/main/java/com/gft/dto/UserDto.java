package com.gft.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by azws on 2016-07-13.
 */

public class UserDto implements Serializable {

    private Long id;
    private String login;
    private BigDecimal availableFunds;
    private BigDecimal portfolioValue;
    private BigDecimal rateOfReturn;

    public UserDto() {};

    public UserDto(Long id, String login, BigDecimal availableFunds, BigDecimal portfolioValue, BigDecimal rateOfReturn) {
        this.id = id;
        this.login = login;
        this.availableFunds = availableFunds;
        this.portfolioValue = portfolioValue;
        this.rateOfReturn = rateOfReturn;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public BigDecimal getAvailableFunds() {
        return availableFunds;
    }

    public void setAvailableFunds(BigDecimal availableFunds) {
        this.availableFunds = availableFunds;
    }

    public BigDecimal getPortfolioValue() {
        return portfolioValue;
    }

    public void setPortfolioValue(BigDecimal portfolioValue) {
        this.portfolioValue = portfolioValue;
    }

    public BigDecimal getRateOfReturn() {
        return rateOfReturn;
    }

    public void setRateOfReturn(BigDecimal rateOfReturn) {
        this.rateOfReturn = rateOfReturn;
    }

    @Override
    public String toString() {
        return "UserDto{" +
                "id=" + id +
                ", login='" + login + '\'' +
                ", availableFunds=" + availableFunds +
                ", portfolioValue=" + portfolioValue +
                ", rateOfReturn=" + rateOfReturn +
                '}';
    }
}