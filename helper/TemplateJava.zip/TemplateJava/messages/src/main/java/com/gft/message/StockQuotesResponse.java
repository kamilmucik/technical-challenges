package com.gft.message;

import com.gft.dto.QuotationDto;
import org.springframework.data.domain.Page;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-30.
 */
public class StockQuotesResponse implements Serializable {

    private Page<QuotationDto> stockQuotes;

    public StockQuotesResponse(Page<QuotationDto> stockQuotes) {
        this.stockQuotes = stockQuotes;
    }

    public Page<QuotationDto> getStockQuotes() {
        return stockQuotes;
    }

    public void setStockQuotes(Page<QuotationDto> stockQuotes) {
        this.stockQuotes = stockQuotes;
    }
}
