package com.gft.message;

import com.gft.dto.OrderDto;
import org.springframework.data.domain.Page;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-23.
 */
public class ActiveOrdersResponse implements Serializable {

    private Page<OrderDto> activeOrders;

    public ActiveOrdersResponse(Page<OrderDto> activeOrders) {
        this.activeOrders = activeOrders;
    }

    public Page<OrderDto> getActiveOrders() {
        return activeOrders;
    }

    public void setActiveOrders(Page<OrderDto> activeOrders) {
        this.activeOrders = activeOrders;
    }
}
