package com.gft.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by azws on 2016-08-10.
 */
public class AssetDto implements Serializable {

    private Long id;

    private ProductDto productDto;

    private BigDecimal price;

    private Integer volume;

    private BigDecimal purchasePrice;

    private BigDecimal profit;

    private Date purchaseDate;

    public AssetDto() {
    }

    public AssetDto(Long id, ProductDto productDto, BigDecimal price, Integer volume, BigDecimal purchasePrice, BigDecimal profit, Date purchaseDate) {
        this.id = id;
        this.productDto = productDto;
        this.price = price;
        this.volume = volume;
        this.purchasePrice = purchasePrice;
        this.profit = profit;
        this.purchaseDate = purchaseDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ProductDto getProductDto() {
        return productDto;
    }

    public void setProductDto(ProductDto productDto) {
        this.productDto = productDto;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    @Override
    public String toString() {
        return "AssetDto{" +
                "id=" + id +
                ", productDto=" + productDto +
                ", price=" + price +
                ", volume=" + volume +
                ", purchasePrice=" + purchasePrice +
                ", profit=" + profit +
                ", purchaseDate=" + purchaseDate +
                '}';
    }
}
