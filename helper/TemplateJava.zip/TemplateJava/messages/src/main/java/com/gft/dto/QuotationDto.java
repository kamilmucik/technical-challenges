package com.gft.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by azws on 2016-07-19.
 */
public class QuotationDto implements Serializable {

    private String productName;
    private BigDecimal exchange;
    private BigDecimal exchangeChange;

    public QuotationDto() {
    }

    public QuotationDto(String productName, BigDecimal exchange, BigDecimal exchangeChange) {
        this.productName = productName;
        this.exchange = exchange;
        this.exchangeChange = exchangeChange;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getExchange() {
        return exchange;
    }

    public void setExchange(BigDecimal exchange) {
        this.exchange = exchange;
    }

    public BigDecimal getExchangeChange() {
        return exchangeChange;
    }

    public void setExchangeChange(BigDecimal exchangeChange) {
        this.exchangeChange = exchangeChange;
    }

    @Override
    public String toString() {
        return "QuotationDto{" +
                "exchangeChange=" + exchangeChange +
                ", exchange=" + exchange +
                ", productName='" + productName + '\'' +
                '}';
    }
}
