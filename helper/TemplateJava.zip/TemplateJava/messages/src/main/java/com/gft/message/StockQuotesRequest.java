package com.gft.message;

import org.springframework.data.domain.Pageable;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-30.
 */
public class StockQuotesRequest implements Serializable {

    private Pageable pageable;

    public StockQuotesRequest(Pageable pageable) {
        this.pageable = pageable;
    }

    public Pageable getPageable() {
        return pageable;
    }

    public void setPageable(Pageable pageable) {
        this.pageable = pageable;
    }
}
