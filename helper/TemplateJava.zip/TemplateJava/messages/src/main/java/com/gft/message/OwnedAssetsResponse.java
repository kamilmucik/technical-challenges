package com.gft.message;

import com.gft.dto.AssetDto;
import com.gft.dto.OrderDto;
import org.springframework.data.domain.Page;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-10.
 */
public class OwnedAssetsResponse implements Serializable {

    private Page<AssetDto> ownedAssets;

    public OwnedAssetsResponse(Page<AssetDto> ownedAssets) {
        this.ownedAssets = ownedAssets;
    }

    public Page<AssetDto> getOwnedAssets() {
        return ownedAssets;
    }

    public void setOwnedAssets(Page<AssetDto> ownedAssets) {
        this.ownedAssets = ownedAssets;
    }
}

