package com.gft.message;

import com.gft.dto.OrderDto;
import org.springframework.data.domain.Pageable;

import java.io.Serializable;

/**
 * Created by azws on 2016-08-08.
 */
public class NewOrderRequest implements Serializable {

    private Long userId;
    private OrderDto orderDto;

    public NewOrderRequest(Long userId, OrderDto orderDto) {
        this.userId = userId;
        this.orderDto = orderDto;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public OrderDto getOrderDto() {
        return orderDto;
    }

    public void setOrderDto(OrderDto orderDto) {
        this.orderDto = orderDto;
    }

}
